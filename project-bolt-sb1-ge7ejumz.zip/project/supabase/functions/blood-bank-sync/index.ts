import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as const;
const PORTAL_URLS = [
  'https://eraktkosh.mohfw.gov.in/BLDAHIMS/bloodbank/stockAvailability.cnt',
  'https://eraktkosh.mohfw.gov.in/BLDAHIMS/bloodbank/nearbyBloodBank.cnt',
  'https://ebloodbank.gov.in',
  'https://www.apredcross.org',
  'https://prakasam.ap.gov.in/public-utility-category/blood-banks',
] as const;

type BloodGroup = typeof BLOOD_GROUPS[number];

type PortalStock = {
  bankName: string;
  city: string;
  stock: Partial<Record<BloodGroup, number>>;
};

function response(body: Record<string, unknown>, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

function normalize(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]/g, '');
}

function cleanText(html: string) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;|&#160;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 150000);
}

async function fetchPortalText(url: string) {
  try {
    const result = await fetch(url, {
      headers: {
        Accept: 'text/html,application/xhtml+xml,application/json',
        'User-Agent': 'HealthCopilot/1.0',
      },
      signal: AbortSignal.timeout(15000),
      redirect: 'follow',
    });
    if (!result.ok) return null;
    const text = await result.text();
    return text.length > 50 ? cleanText(text) : null;
  } catch {
    return null;
  }
}

function validateStock(value: unknown): PortalStock[] {
  if (!Array.isArray(value)) return [];
  const rows: PortalStock[] = [];

  for (const item of value) {
    if (!item || typeof item !== 'object') continue;
    const record = item as Record<string, unknown>;
    if (typeof record.bankName !== 'string' || typeof record.city !== 'string') continue;

    const stock: Partial<Record<BloodGroup, number>> = {};
    for (const group of BLOOD_GROUPS) {
      const units = record.stock && typeof record.stock === 'object'
        ? (record.stock as Record<string, unknown>)[group]
        : undefined;
      if (typeof units === 'number' && Number.isInteger(units) && units >= 0 && units <= 100000) {
        stock[group] = units;
      }
    }

    if (Object.keys(stock).length > 0) {
      rows.push({ bankName: record.bankName.trim(), city: record.city.trim(), stock });
    }
  }

  return rows;
}

async function extractWithAi(portalText: string): Promise<PortalStock[]> {
  const apiKey = Deno.env.get('GEMINI_API_KEY');
  if (!apiKey) return [];

  const prompt = `Extract blood inventory from this government blood-bank portal text.
Return ONLY a JSON array. Each item must have this exact shape:
{"bankName":"exact displayed bank name","city":"exact displayed city","stock":{"A+":0,"A-":0}}
Include only blood groups and unit counts explicitly shown in the source. Do not estimate, infer, complete, or invent missing values. Omit a bank if no explicit numeric stock value is present. Use integer units from 0 to 100000.

SOURCE TEXT:
${portalText}`;

  try {
    const result = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${encodeURIComponent(apiKey)}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0, responseMimeType: 'application/json' },
        }),
        signal: AbortSignal.timeout(25000),
      },
    );
    if (!result.ok) return [];

    const payload = await result.json() as {
      candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
    };
    const text = payload.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text) return [];
    return validateStock(JSON.parse(text));
  } catch {
    return [];
  }
}

function findBank(rows: Array<{ id: string; name: string; city: string }>, match: PortalStock) {
  const bankName = normalize(match.bankName);
  const city = normalize(match.city);
  return rows.find(bank => {
    const knownName = normalize(bank.name);
    const knownCity = normalize(bank.city);
    return (knownName === bankName || knownName.includes(bankName) || bankName.includes(knownName)) &&
      (knownCity === city || knownCity.includes(city) || city.includes(knownCity));
  });
}

async function performSync(supabase: ReturnType<typeof createClient>) {
  const { data: banks, error: banksError } = await supabase
    .from('blood_banks')
    .select('id, name, city');
  if (banksError) throw banksError;
  if (!banks?.length) return { updated: 0, banks: 0, source: 'no_banks' as const, portals_checked: 0, portals_available: 0 };

  const portalResults = await Promise.all(PORTAL_URLS.map(async url => ({
    url,
    text: await fetchPortalText(url),
  })));
  const availablePortals = portalResults.filter(result => result.text);
  const extracted = (await Promise.all(availablePortals.map(result => extractWithAi(result.text!)))).flat();

  const { data: existing, error: stockError } = await supabase
    .from('blood_stock')
    .select('id, bank_id, blood_group');
  if (stockError) throw stockError;

  const existingMap = new Map<string, string>();
  for (const row of existing ?? []) existingMap.set(`${row.bank_id}:${row.blood_group}`, row.id);

  const now = new Date().toISOString();
  const updates: Array<Record<string, unknown>> = [];
  for (const match of extracted) {
    const bank = findBank(banks, match);
    if (!bank) continue;
    for (const group of BLOOD_GROUPS) {
      const units = match.stock[group];
      if (units === undefined) continue;
      const key = `${bank.id}:${group}`;
      updates.push({
        ...(existingMap.has(key) ? { id: existingMap.get(key) } : {}),
        bank_id: bank.id,
        blood_group: group,
        units,
        reported_at: now,
        verified: true,
        source: 'ai-government-portal',
      });
    }
  }

  if (updates.length > 0) {
    const { error: upsertError } = await supabase
      .from('blood_stock')
      .upsert(updates, { onConflict: 'bank_id,blood_group' });
    if (upsertError) throw upsertError;
  }

  return {
    updated: updates.length,
    banks: banks.length,
    source: updates.length > 0 ? 'ai-government-portal' as const : availablePortals.length > 0 ? 'portal-no-readable-stock' as const : 'portals-unavailable' as const,
    portals_checked: PORTAL_URLS.length,
    portals_available: availablePortals.length,
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return response({}, 200);
  if (req.method !== 'POST') return response({ error: 'Method not allowed' }, 405);

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    );

    const cronHeader = req.headers.get('x-cron-secret');
    const cronSecret = Deno.env.get('CRON_SECRET');
    if (cronSecret && cronHeader === cronSecret) {
      const result = await performSync(supabase);
      return response(result);
    }

    const authorization = req.headers.get('Authorization');
    if (!authorization?.startsWith('Bearer ')) return response({ error: 'Authentication required' }, 401);
    const token = authorization.slice('Bearer '.length);

    if (cronSecret && token === cronSecret) {
      const result = await performSync(supabase);
      return response(result);
    }

    // Accept the project anon key for cron-triggered syncs
    const expectedAnonKey = Deno.env.get('SUPABASE_ANON_KEY')
      ?? Deno.env.get('ANON_KEY')
      ?? 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InV2cW1zZmN0a3R2d2hrZ3dnZm16Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE2NjA1MjQsImV4cCI6MjEwNzIzNjUyNH0.a1VblBIKEralNw5BIOZbn1sFDRDtVwX77QU0SOxmUl4';
    if (token === expectedAnonKey) {
      const result = await performSync(supabase);
      return response(result);
    }

    const { data: authData, error: authError } = await supabase.auth.getUser(token);
    if (authError || !authData.user) return response({ error: 'Authentication required' }, 401);

    const result = await performSync(supabase);
    return response(result);
  } catch {
    return response({ error: 'Blood-bank update failed' }, 500);
  }
});
