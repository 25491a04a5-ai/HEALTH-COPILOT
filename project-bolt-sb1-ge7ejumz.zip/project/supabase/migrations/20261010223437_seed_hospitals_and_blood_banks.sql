/*
# Seed: Hospitals and Blood Banks

## Overview
Seeds the hospitals table with real hospital data from the hospital_list.txt file
and the blood_banks table with real blood bank data from Andhra_Pradesh_Blood_banks.txt.

## Hospitals Seeded (from hospital_list.txt)
All hospitals are in the Ongole region. Includes specialties:
- Cardiology: Sri Datta Super Speciality Hospitals, Vivekananda Super Speciality Hospital
- Pulmonology: Sri Datta Super Speciality Hospitals, Kondapalli Chest Hospital
- Neurology: Sri Datta Super Speciality Hospitals, Sims Neurology and Endocrinology Hospital, Assure Multispeciality Hospital
- Gastroenterology: Ravindra Gastro and Liver Care Hospitals, Assure Multispeciality Hospital
- Urology: Sri Datta Super Speciality Hospitals, Kidney Care Hospital
- Dermatology: Kosuru Kidney & Skin Hospital, Balaji Skin Hospital
- Orthopaedics: Susmitha Orthopedic Hospital, Sri Datta Super Speciality Hospitals
- Ophthalmology: Dr. M. V. Reddy Eye Hospital, Dr. Ramalinga Reddy Maxivision Super Speciality Eye Hospital
- ENT: Kondaveedu ENT Hospitals, Sudeep ENT Care

## Blood Banks Seeded (from Andhra_Pradesh_Blood_banks.txt)
- Ongole: Indian Red Cross Society, Navya Blood Bank, RIMS General Hospital Blood Bank
- Guntur: Govt General Hospital Blood Bank, Red Cross Blood Bank, Needs Blood Bank
- Narsaraopeta: NRT Blood Bank, Palnadu Blood Centre, Vijaya Blood Centre

## Blood Stock
Each blood bank gets initial stock entries for all 8 blood groups (A+, A-, B+, B-, AB+, AB-, O+, O-) set to 0.
*/

-- =====================
-- HOSPITALS
-- =====================

INSERT INTO hospitals (name, specialty, address, phone, has_emergency, zone) VALUES
-- Cardiology
('Sri Datta Super Speciality Hospitals', 'Cardiology', 'Ongole, Andhra Pradesh', 'sridattahospitals.in', true, 'Ongole'),
('Vivekananda Super Speciality Hospital', 'Cardiology', 'Ongole, Andhra Pradesh', '6305234649', true, 'Ongole'),
-- Pulmonology
('Sri Datta Super Speciality Hospitals', 'Pulmonology', 'Ongole, Andhra Pradesh', 'sridattahospitals.in', true, 'Ongole'),
('Kondapalli Chest Hospital', 'Pulmonology', 'Ongole, Andhra Pradesh', '08647 227227', true, 'Ongole'),
-- Neurology
('Sri Datta Super Speciality Hospitals', 'Neurology', 'Ongole, Andhra Pradesh', 'sridattahospitals.in', true, 'Ongole'),
('Sims Neurology and Endocrinology Hospital', 'Neurology', 'Ongole, Andhra Pradesh', '08647 231111', true, 'Ongole'),
('Assure Multispeciality Hospital', 'Neurology', 'Ongole, Andhra Pradesh', '08121 415561', true, 'Ongole'),
-- Gastroenterology
('Ravindra Gastro and Liver Care Hospitals', 'Gastroenterology', 'Ongole, Andhra Pradesh', '90596 47047', true, 'Ongole'),
('Assure Multispeciality Hospital', 'Gastroenterology', 'Ongole, Andhra Pradesh', '08121 415561', true, 'Ongole'),
-- Urology
('Sri Datta Super Speciality Hospitals', 'Urology', 'Ongole, Andhra Pradesh', 'sridattahospitals.in', true, 'Ongole'),
('Kidney Care Hospital', 'Urology', 'Ongole, Andhra Pradesh', '70365 55545', false, 'Ongole'),
-- Dermatology
('Kosuru Kidney & Skin Hospital', 'Dermatology', 'Ongole, Andhra Pradesh', '83338 33210', false, 'Ongole'),
('Balaji Skin Hospital', 'Dermatology', 'Ongole, Andhra Pradesh', '94944 40535', false, 'Ongole'),
-- Orthopaedics
('Susmitha Orthopedic Hospital', 'Orthopaedics', 'Ongole, Andhra Pradesh', '08647 229667', true, 'Ongole'),
('Sri Datta Super Speciality Hospitals', 'Orthopaedics', 'Ongole, Andhra Pradesh', 'sridattahospitals.in', true, 'Ongole'),
-- Ophthalmology
('Dr. M. V. Reddy Eye Hospital', 'Ophthalmology', 'Ongole, Andhra Pradesh', '78423 29009', false, 'Ongole'),
('Dr. Ramalinga Reddy Maxivision Super Speciality Eye Hospital', 'Ophthalmology', 'Ongole, Andhra Pradesh', '92402 14613', false, 'Ongole'),
-- ENT
('Kondaveedu ENT Hospitals', 'ENT', '20/A, North Bypass Road, NH-5, Mukthinuthalapadu, Ongole', '08592667788', true, 'Ongole'),
('Sudeep ENT Care', 'ENT', 'Ongole, Andhra Pradesh', '95158 54503', false, 'Ongole');

-- =====================
-- BLOOD BANKS
-- =====================

INSERT INTO blood_banks (name, address, phone, city) VALUES
-- Ongole
('Indian Red Cross Society', 'Santhapet, Railway Station Road, Ongole', '9849337298', 'Ongole'),
('Navya Blood Bank', 'Opposite RTC Bus Stand, Venkateswara Complex, Ongole', '9966344449', 'Ongole'),
('RIMS General Hospital Blood Bank', 'RIMS Medical College/Hospital Campus, Ongole', '9000991884', 'Ongole'),
-- Guntur
('Govt General Hospital Blood Bank', 'Opposite Railway Station, Guntur', '0863-2220035', 'Guntur'),
('Red Cross Blood Bank', 'Zilla Parishad Compound, Guntur', '0863-2215656', 'Guntur'),
('Needs Blood Bank', 'Kothapeta Main Road, Guntur', '9966494704', 'Guntur'),
-- Narsaraopeta
('NRT Blood Bank', 'GBR Super Speciality Hospital, Palnadu Road, Narsaraopeta', '9542628888', 'Narsaraopeta'),
('Palnadu Blood Centre', 'Opposite Mahatma Gandhi Hospital, Narsaraopeta', '8074115777', 'Narsaraopeta'),
('Vijaya Blood Centre', '1st Floor Karur Vysya Bank, Narsaraopeta', '9177047793', 'Narsaraopeta');

-- =====================
-- INITIAL BLOOD STOCK (all groups at 0)
-- =====================

INSERT INTO blood_stock (bank_id, blood_group, units, reported_at)
SELECT b.id, g.group_name, 0, NULL
FROM blood_banks b
CROSS JOIN (VALUES ('A+'),('A-'),('B+'),('B-'),('AB+'),('AB-'),('O+'),('O-')) AS g(group_name)
WHERE NOT EXISTS (
  SELECT 1 FROM blood_stock bs WHERE bs.bank_id = b.id AND bs.blood_group = g.group_name
);
