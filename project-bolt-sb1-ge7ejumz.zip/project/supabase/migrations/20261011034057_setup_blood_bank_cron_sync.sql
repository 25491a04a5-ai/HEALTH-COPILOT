/*
# Set up automatic 5-hour blood bank sync via pg_cron

## What this does
1. Installs `pg_cron` extension for scheduled database jobs
2. Installs `pg_net` extension for making HTTP requests from PostgreSQL
3. Creates a stored function `sync_blood_banks_cron()` that calls the `blood-bank-sync` edge function
4. Schedules the function to run every 5 hours automatically

## How it works
- Every 5 hours, pg_cron calls `sync_blood_banks_cron()`
- The function uses `pg_net.http_post` to send a POST request to the edge function URL
- The edge function fetches official government blood bank portals, uses AI to extract stock data, and updates the `blood_stock` table
- The anon key is used for authentication; the edge function accepts it as a fallback when no CRON_SECRET is configured

## Security
- The sync function only calls our own edge function — no external URLs are exposed
- The anon key is safe to use here because the edge function only performs read-only portal fetches and stock upserts
- pg_cron jobs run in the `postgres` schema and are not callable by anon/authenticated roles

## Important notes
1. The edge function URL is derived from the project's Supabase URL
2. The schedule runs at 5-hour intervals: 00:00, 05:00, 10:00, 15:00, 20:00 UTC
3. The `pg_net` request is asynchronous — it fires and forgets, the response is not needed
*/

-- Install pg_cron (must be in postgres schema, requires superuser)
CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA pg_catalog;

-- Install pg_net for HTTP requests from database
CREATE EXTENSION IF NOT EXISTS pg_net SCHEMA extensions;

-- Create the sync function
CREATE OR REPLACE FUNCTION public.sync_blood_banks_cron()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_edge_url text;
  v_anon_key text;
BEGIN
  -- Build the edge function URL from the project reference
  v_edge_url := 'https://uvqmsfctktvwhkgwgfmz.supabase.co/functions/v1/blood-bank-sync';
  
  -- Use the anon key for authentication
  v_anon_key := current_setting('app.supabase_anon_key', true);
  
  -- If not set via setting, use the known project anon key
  IF v_anon_key IS NULL OR v_anon_key = '' THEN
    v_anon_key := 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InV2cW1zZmN0a3R2d2hrZ3dnZm16Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTE2NjA1MjQsImV4cCI6MjEwNzIzNjUyNH0.a1VblBIKEralNw5BIOZbn1sFDRDtVwX77QU0SOxmUl4';
  END IF;

  -- Fire the HTTP POST request asynchronously (fire and forget)
  PERFORM net.http_post(
    url := v_edge_url,
    headers := jsonb_build_object(
      'Content-Type', 'application/json',
      'Authorization', 'Bearer ' || v_anon_key
    ),
    body := '{}'::jsonb
  );
END;
$$;

-- Revoke execute from public; only cron should call this
REVOKE EXECUTE ON FUNCTION public.sync_blood_banks_cron() FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.sync_blood_banks_cron() FROM anon;
REVOKE EXECUTE ON FUNCTION public.sync_blood_banks_cron() FROM authenticated;

-- Schedule the sync every 5 hours (at 00:00, 05:00, 10:00, 15:00, 20:00 UTC)
-- Using cron.schedule with the job name for easy management
SELECT cron.schedule(
  'blood-bank-auto-sync',
  '0 0,5,10,15,20 * * *',
  $$SELECT public.sync_blood_banks_cron();$$
);
