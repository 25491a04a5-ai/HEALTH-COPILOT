/*
# HealthCopilot — Database Schema

## Overview
Creates the full database schema for HealthCopilot, a health records and blood bank management app.
Supports: private patient reports per user, hospital directory, blood bank directory with live stock updates,
and staff assignments for blood bank management.

## New Tables

1. **hospitals** — Directory of hospitals with specialty, address, phone, emergency status.
   - id (uuid PK), name, specialty (text), address (text), phone (text), has_emergency (bool), zone (text), created_at

2. **blood_banks** — Directory of blood banks with address, phone, city.
   - id (uuid PK), name, address (text), phone (text), city (text), created_at

3. **blood_stock** — Live stock levels per blood bank per blood group.
   - id (uuid PK), bank_id (FK → blood_banks), blood_group (text), units (int), reported_at (timestamptz)
   - Unique constraint on (bank_id, blood_group)

4. **patient_reports** — Private medical reports per user.
   - id (uuid PK), user_id (uuid DEFAULT auth.uid()), title, type, report_date, hospital, created_at

5. **bank_staff** — Maps users to blood banks they can update stock for.
   - id (uuid PK), user_id (uuid DEFAULT auth.uid()), bank_id (FK → blood_banks), created_at
   - Unique on user_id

## Security (RLS)
- **hospitals**: Public read (anon + authenticated), no writes from client.
- **blood_banks**: Public read, no writes from client.
- **blood_stock**: Public read, inserts/updates only by assigned staff (via bank_staff membership).
- **patient_reports**: Owner-scoped CRUD (authenticated, auth.uid() = user_id).
- **bank_staff**: Owner-scoped (user can read/delete their own staff assignment).
*/

-- =====================
-- TABLES (all first)
-- =====================

CREATE TABLE IF NOT EXISTS hospitals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  specialty text NOT NULL,
  address text,
  phone text,
  has_emergency boolean NOT NULL DEFAULT false,
  zone text NOT NULL DEFAULT 'Ongole',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS blood_banks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  address text,
  phone text,
  city text NOT NULL DEFAULT 'Ongole',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS blood_stock (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  bank_id uuid NOT NULL REFERENCES blood_banks(id) ON DELETE CASCADE,
  blood_group text NOT NULL,
  units integer NOT NULL DEFAULT 0,
  reported_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  UNIQUE(bank_id, blood_group)
);

CREATE TABLE IF NOT EXISTS patient_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  type text NOT NULL DEFAULT 'Lab',
  report_date date NOT NULL,
  hospital text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS bank_staff (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  bank_id uuid NOT NULL REFERENCES blood_banks(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- =====================
-- RLS + POLICIES
-- =====================

-- Hospitals: public read
ALTER TABLE hospitals ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "public_read_hospitals" ON hospitals;
CREATE POLICY "public_read_hospitals" ON hospitals FOR SELECT
  TO anon, authenticated USING (true);

-- Blood banks: public read
ALTER TABLE blood_banks ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "public_read_blood_banks" ON blood_banks;
CREATE POLICY "public_read_blood_banks" ON blood_banks FOR SELECT
  TO anon, authenticated USING (true);

-- Blood stock: public read, staff-only write
ALTER TABLE blood_stock ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "public_read_blood_stock" ON blood_stock;
CREATE POLICY "public_read_blood_stock" ON blood_stock FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "staff_insert_blood_stock" ON blood_stock;
CREATE POLICY "staff_insert_blood_stock" ON blood_stock FOR INSERT
  TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM bank_staff WHERE bank_staff.user_id = auth.uid() AND bank_staff.bank_id = blood_stock.bank_id)
  );

DROP POLICY IF EXISTS "staff_update_blood_stock" ON blood_stock;
CREATE POLICY "staff_update_blood_stock" ON blood_stock FOR UPDATE
  TO authenticated USING (
    EXISTS (SELECT 1 FROM bank_staff WHERE bank_staff.user_id = auth.uid() AND bank_staff.bank_id = blood_stock.bank_id)
  ) WITH CHECK (
    EXISTS (SELECT 1 FROM bank_staff WHERE bank_staff.user_id = auth.uid() AND bank_staff.bank_id = blood_stock.bank_id)
  );

-- Patient reports: owner-scoped CRUD
ALTER TABLE patient_reports ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "select_own_reports" ON patient_reports;
CREATE POLICY "select_own_reports" ON patient_reports FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_reports" ON patient_reports;
CREATE POLICY "insert_own_reports" ON patient_reports FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_reports" ON patient_reports;
CREATE POLICY "update_own_reports" ON patient_reports FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_reports" ON patient_reports;
CREATE POLICY "delete_own_reports" ON patient_reports FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Bank staff: owner-scoped
ALTER TABLE bank_staff ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "select_own_staff" ON bank_staff;
CREATE POLICY "select_own_staff" ON bank_staff FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_staff" ON bank_staff;
CREATE POLICY "insert_own_staff" ON bank_staff FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_staff" ON bank_staff;
CREATE POLICY "delete_own_staff" ON bank_staff FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Enable realtime on blood_stock
ALTER TABLE blood_stock REPLICA IDENTITY FULL;
