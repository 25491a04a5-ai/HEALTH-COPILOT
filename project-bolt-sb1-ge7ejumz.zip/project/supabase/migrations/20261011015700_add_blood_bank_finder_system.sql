/*
# Blood Bank Finder and Management System

## Summary
1. Enhances blood_banks table with district, state, pincode, lat/lng, operating_hours, verification fields.
2. Enhances blood_stock with verified boolean and source text.
3. Creates blood_requests table for emergency blood requests.
4. Creates blood_bank_admins table for admin access control.
5. Sets up RLS: public read for blood banks/stock/requests; admin-only writes for blood bank records; public can submit blood requests.

## Important: Tables are created BEFORE policies that reference them.
*/

-- ─── Enhance blood_banks table (additive only) ───
ALTER TABLE blood_banks ADD COLUMN IF NOT EXISTS district text;
ALTER TABLE blood_banks ADD COLUMN IF NOT EXISTS state text DEFAULT 'Andhra Pradesh';
ALTER TABLE blood_banks ADD COLUMN IF NOT EXISTS pincode text;
ALTER TABLE blood_banks ADD COLUMN IF NOT EXISTS latitude double precision;
ALTER TABLE blood_banks ADD COLUMN IF NOT EXISTS longitude double precision;
ALTER TABLE blood_banks ADD COLUMN IF NOT EXISTS operating_hours text;
ALTER TABLE blood_banks ADD COLUMN IF NOT EXISTS data_source text DEFAULT 'manual';
ALTER TABLE blood_banks ADD COLUMN IF NOT EXISTS verified boolean DEFAULT false;
ALTER TABLE blood_banks ADD COLUMN IF NOT EXISTS last_verified_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_blood_banks_city ON blood_banks(city);
CREATE INDEX IF NOT EXISTS idx_blood_banks_district ON blood_banks(district);
CREATE INDEX IF NOT EXISTS idx_blood_banks_state ON blood_banks(state);
CREATE INDEX IF NOT EXISTS idx_blood_banks_pincode ON blood_banks(pincode);

-- ─── Enhance blood_stock table (additive only) ───
ALTER TABLE blood_stock ADD COLUMN IF NOT EXISTS verified boolean DEFAULT false;
ALTER TABLE blood_stock ADD COLUMN IF NOT EXISTS source text;

-- ─── Create blood_requests table ───
CREATE TABLE IF NOT EXISTS blood_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_name text NOT NULL,
  blood_group text NOT NULL CHECK (blood_group IN ('A+','A-','B+','B-','AB+','AB-','O+','O-')),
  hospital_name text NOT NULL,
  hospital_location text NOT NULL,
  contact_name text NOT NULL,
  contact_phone text NOT NULL,
  units_needed integer NOT NULL DEFAULT 1 CHECK (units_needed >= 1 AND units_needed <= 20),
  urgency text NOT NULL DEFAULT 'critical' CHECK (urgency IN ('critical','urgent','moderate')),
  notes text,
  fulfilled boolean DEFAULT false,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE blood_requests ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_blood_requests_blood_group ON blood_requests(blood_group);
CREATE INDEX IF NOT EXISTS idx_blood_requests_created_at ON blood_requests(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_blood_requests_urgency ON blood_requests(urgency);

-- ─── Create blood_bank_admins table ───
CREATE TABLE IF NOT EXISTS blood_bank_admins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE blood_bank_admins ENABLE ROW LEVEL SECURITY;

-- ─── Now create all policies (tables exist) ───

-- blood_banks: public read, admin-only writes
DROP POLICY IF EXISTS "public_select_blood_banks" ON blood_banks;
CREATE POLICY "public_select_blood_banks"
  ON blood_banks FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "admin_insert_blood_banks" ON blood_banks;
CREATE POLICY "admin_insert_blood_banks"
  ON blood_banks FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM blood_bank_admins WHERE user_id = auth.uid()));

DROP POLICY IF EXISTS "admin_update_blood_banks" ON blood_banks;
CREATE POLICY "admin_update_blood_banks"
  ON blood_banks FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM blood_bank_admins WHERE user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM blood_bank_admins WHERE user_id = auth.uid()));

DROP POLICY IF EXISTS "admin_delete_blood_banks" ON blood_banks;
CREATE POLICY "admin_delete_blood_banks"
  ON blood_banks FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM blood_bank_admins WHERE user_id = auth.uid()));

-- blood_stock: public read, admin or bank staff can write
DROP POLICY IF EXISTS "public_select_blood_stock" ON blood_stock;
CREATE POLICY "public_select_blood_stock"
  ON blood_stock FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "staff_insert_blood_stock" ON blood_stock;
CREATE POLICY "staff_insert_blood_stock"
  ON blood_stock FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM blood_bank_admins WHERE user_id = auth.uid())
    OR EXISTS (SELECT 1 FROM bank_staff WHERE bank_staff.user_id = auth.uid() AND bank_staff.bank_id = blood_stock.bank_id)
  );

DROP POLICY IF EXISTS "staff_update_blood_stock" ON blood_stock;
CREATE POLICY "staff_update_blood_stock"
  ON blood_stock FOR UPDATE TO authenticated
  USING (
    EXISTS (SELECT 1 FROM blood_bank_admins WHERE user_id = auth.uid())
    OR EXISTS (SELECT 1 FROM bank_staff WHERE bank_staff.user_id = auth.uid() AND bank_staff.bank_id = blood_stock.bank_id)
  )
  WITH CHECK (
    EXISTS (SELECT 1 FROM blood_bank_admins WHERE user_id = auth.uid())
    OR EXISTS (SELECT 1 FROM bank_staff WHERE bank_staff.user_id = auth.uid() AND bank_staff.bank_id = blood_stock.bank_id)
  );

DROP POLICY IF EXISTS "admin_delete_blood_stock" ON blood_stock;
CREATE POLICY "admin_delete_blood_stock"
  ON blood_stock FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM blood_bank_admins WHERE user_id = auth.uid()));

-- blood_requests: public read + insert, admin/owner delete + update
DROP POLICY IF EXISTS "public_select_blood_requests" ON blood_requests;
CREATE POLICY "public_select_blood_requests"
  ON blood_requests FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_insert_blood_requests" ON blood_requests;
CREATE POLICY "public_insert_blood_requests"
  ON blood_requests FOR INSERT TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "admin_delete_blood_requests" ON blood_requests;
CREATE POLICY "admin_delete_blood_requests"
  ON blood_requests FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM blood_bank_admins WHERE blood_bank_admins.user_id = auth.uid()));

DROP POLICY IF EXISTS "owner_update_blood_requests" ON blood_requests;
CREATE POLICY "owner_update_blood_requests"
  ON blood_requests FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR EXISTS (SELECT 1 FROM blood_bank_admins WHERE blood_bank_admins.user_id = auth.uid()))
  WITH CHECK (true);

-- blood_bank_admins: admin-only management
DROP POLICY IF EXISTS "admin_select_admins" ON blood_bank_admins;
CREATE POLICY "admin_select_admins"
  ON blood_bank_admins FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR EXISTS (SELECT 1 FROM blood_bank_admins bba WHERE bba.user_id = auth.uid()));

DROP POLICY IF EXISTS "admin_insert_admins" ON blood_bank_admins;
CREATE POLICY "admin_insert_admins"
  ON blood_bank_admins FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM blood_bank_admins WHERE user_id = auth.uid()));

DROP POLICY IF EXISTS "admin_delete_admins" ON blood_bank_admins;
CREATE POLICY "admin_delete_admins"
  ON blood_bank_admins FOR DELETE TO authenticated
  USING (user_id = auth.uid() OR EXISTS (SELECT 1 FROM blood_bank_admins WHERE user_id = auth.uid()));
