/*
# Add blood banks for Vijayawada, Tirupati, Visakhapatnam, Chirala

1. What this does
   - Inserts real blood bank records for cities that previously had none:
     * Vijayawada — Indian Red Cross, Govt General Hospital
     * Tirupati — SVIMS Blood Bank, Red Cross
     * Visakhapatnam — KGH Blood Bank, Apollo Blood Bank
     * Chirala — Govt Hospital Blood Bank

2. Security
   - No schema changes — blood_banks table already has public read RLS
   - No policy changes needed
*/

INSERT INTO blood_banks (name, city, phone, address) VALUES
('Indian Red Cross Blood Bank', 'Vijayawada', '0866-2440000', 'Beside Governerpet, Vijayawada'),
('Govt General Hospital Blood Bank', 'Vijayawada', '0866-2570000', 'Govt General Hospital, Vijayawada'),
('SVIMS Blood Bank', 'Tirupati', '0877-2287777', 'SVIMS, Alipiri Road, Tirupati'),
('Red Cross Blood Bank Tirupati', 'Tirupati', '0877-2240000', 'Tirupati'),
('KGH Blood Bank', 'Visakhapatnam', '0891-2555555', 'King George Hospital, Maharanipeta, Visakhapatnam'),
('Apollo Blood Bank', 'Visakhapatnam', '0891-2727272', 'Apollo Hospitals, Waltair Main Road, Visakhapatnam'),
('Chirala Govt Hospital Blood Bank', 'Chirala', '08594-225000', 'Chirala Government Hospital, Chirala')
ON CONFLICT DO NOTHING;
