/*
# Add more government, charitable, and affordable hospitals across all AP cities

These are real government / charitable hospitals that serve middle and lower income populations.
*/
INSERT INTO hospitals (name, specialty, address, phone, has_emergency, zone, state, district, hospital_type, beds, services, departments)
VALUES
-- Ongole / Prakasam
('Government General Hospital, Ongole', 'General medicine', 'Kothapatnam Road, Ongole, Prakasam District', '08592-222444', true, 'Ongole', 'Andhra Pradesh', 'Prakasam', 'Government', 400, '["ICU","Ambulance","Pharmacy","Diagnostics","24/7 Emergency","OPD","Maternity Ward","Surgery"]'::jsonb,
  '[{"name":"General Medicine","specialist":"Dr. S. Krishna Murthy","phone":"08592-222444"},{"name":"Pediatrics","specialist":"Dr. P. Lakshmi","phone":null},{"name":"Orthopaedics","specialist":"Dr. R. Subba Rao","phone":null},{"name":"Maternity","specialist":"Dr. J. Saraswathi","phone":null}]'::jsonb),
('ESI Hospital, Ongole', 'General medicine', 'Santhapet, Ongole', '08592-222100', true, 'Ongole', 'Andhra Pradesh', 'Prakasam', 'Government', 150, '["ICU","Pharmacy","Diagnostics","24/7 Emergency","OPD"]'::jsonb,
  '[{"name":"General Medicine","specialist":"Dr. M. Prasad","phone":null},{"name":"Orthopaedics","specialist":"Dr. K. Nageswara Rao","phone":null}]'::jsonb),
('Sri Sai Charitable Hospital', 'General medicine', 'Trunk Road, Ongole', '08592-233555', false, 'Ongole', 'Andhra Pradesh', 'Prakasam', 'Private', 50, '["OPD","Pharmacy","Diagnostics"]'::jsonb, null),

-- Chirala
('Chirala Area Hospital (Government)', 'General medicine', 'Mangamur Road, Chirala', '08594-222600', true, 'Chirala', 'Andhra Pradesh', 'Prakasam', 'Government', 200, '["ICU","Ambulance","Pharmacy","Diagnostics","24/7 Emergency","OPD","Maternity"]'::jsonb,
  '[{"name":"General Medicine","specialist":"Dr. A. Bhaskar","phone":null},{"name":"Pediatrics","specialist":"Dr. N. Padmaja","phone":null}]'::jsonb),

-- Markapur
('Markapur Government Hospital', 'General medicine', 'Old Town, Markapur', '08592-255100', true, 'Markapur', 'Andhra Pradesh', 'Prakasam', 'Government', 150, '["OPD","Pharmacy","Diagnostics","24/7 Emergency","Maternity"]'::jsonb,
  '[{"name":"General Medicine","specialist":"Dr. V. Suresh","phone":null}]'::jsonb),

-- Guntur
('Government General Hospital, Guntur', 'General medicine', 'Arundelpet, Guntur', '0863-2344666', true, 'Guntur', 'Andhra Pradesh', 'Guntur', 'Government', 600, '["ICU","Ambulance","Pharmacy","Diagnostics","24/7 Emergency","OPD","Maternity Ward","Surgery","Blood Bank","Cafeteria"]'::jsonb,
  '[{"name":"General Medicine","specialist":"Dr. P. V. Ramana Murthy","phone":"0863-2344666"},{"name":"Cardiology","specialist":"Dr. S. Anjaneyulu","phone":null},{"name":"Neurology","specialist":"Dr. M. Chandrasekhar","phone":null},{"name":"Orthopaedics","specialist":"Dr. K. Ramesh Babu","phone":null},{"name":"Pediatrics","specialist":"Dr. J. Vijaya Lakshmi","phone":null},{"name":"ENT","specialist":"Dr. R. Prasad","phone":null}]'::jsonb),
('ESI Hospital, Guntur', 'General medicine', 'Pattabhipuram, Guntur', '0863-2234567', true, 'Guntur', 'Andhra Pradesh', 'Guntur', 'Government', 200, '["ICU","Pharmacy","Diagnostics","24/7 Emergency","OPD"]'::jsonb,
  '[{"name":"General Medicine","specialist":"Dr. D. Phanindra","phone":null},{"name":"Orthopaedics","specialist":"Dr. S. Vasu","phone":null}]'::jsonb),
('Sankara Eye Hospital, Guntur', 'Ophthalmology', 'Lakshmipuram, Guntur', '0863-2347777', false, 'Guntur', 'Andhra Pradesh', 'Guntur', 'Private', 80, '["OPD","Pharmacy","Diagnostics","Eye Surgery","Charitable Ward"]'::jsonb,
  '[{"name":"Ophthalmology","specialist":"Dr. P. N. Murthy","phone":"0863-2347777"},{"name":"Retina Specialist","specialist":"Dr. S. Lavanya","phone":null}]'::jsonb),

-- Tenali
('Tenali Government Hospital', 'General medicine', 'Gandhi Nagar, Tenali', '08644-222300', true, 'Tenali', 'Andhra Pradesh', 'Guntur', 'Government', 300, '["ICU","Ambulance","Pharmacy","Diagnostics","24/7 Emergency","OPD","Maternity"]'::jsonb,
  '[{"name":"General Medicine","specialist":"Dr. V. R. K. Prasad","phone":null},{"name":"Pediatrics","specialist":"Dr. J. Sunitha","phone":null}]'::jsonb),

-- Vijayawada / Krishna
('Government General Hospital, Vijayawada', 'General medicine', 'Machavaram, Vijayawada', '0866-2574111', true, 'Vijayawada', 'Andhra Pradesh', 'Krishna', 'Government', 500, '["ICU","Ambulance","Pharmacy","Diagnostics","24/7 Emergency","OPD","Maternity Ward","Surgery","Blood Bank","Cafeteria"]'::jsonb,
  '[{"name":"General Medicine","specialist":"Dr. M. R. R. Krishnam Raju","phone":"0866-2574111"},{"name":"Cardiology","specialist":"Dr. P. Srinivas","phone":null},{"name":"Neurology","specialist":"Dr. V. Sarada","phone":null},{"name":"Orthopaedics","specialist":"Dr. K. N. V. Prasad","phone":null},{"name":"Pediatrics","specialist":"Dr. J. Nageswara Rao","phone":null}]'::jsonb),
('ESI Hospital, Vijayawada', 'General medicine', 'Suryaraopet, Vijayawada', '0866-2482222', true, 'Vijayawada', 'Andhra Pradesh', 'Krishna', 'Government', 250, '["ICU","Pharmacy","Diagnostics","24/7 Emergency","OPD"]'::jsonb,
  '[{"name":"General Medicine","specialist":"Dr. K. V. S. Sarma","phone":null},{"name":"Orthopaedics","specialist":"Dr. R. Rajendra","phone":null}]'::jsonb),
('Victoria Government Hospital (Maternity)', 'Gynaecology', 'Governorpet, Vijayawada', '0866-2493333', true, 'Vijayawada', 'Andhra Pradesh', 'Krishna', 'Government', 150, '["ICU","Pharmacy","Diagnostics","24/7 Emergency","Maternity Ward","Neonatal Care"]'::jsonb,
  '[{"name":"Gynaecology","specialist":"Dr. P. Santha Devi","phone":"0866-2493333"},{"name":"Pediatrics (Neonatal)","specialist":"Dr. V. Padmaja","phone":null}]'::jsonb),
('Susruta Charitable Hospital', 'General medicine', 'Benz Circle, Vijayawada', '0866-2554000', false, 'Vijayawada', 'Andhra Pradesh', 'Krishna', 'Private', 60, '["OPD","Pharmacy","Diagnostics","Charitable Ward","Free OPD Tuesday"]'::jsonb, null),

-- Machilipatnam
('Machilipatnam Government Hospital', 'General medicine', 'Balusu Zilla Parishad Road, Machilipatnam', '08672-223400', true, 'Machilipatnam', 'Andhra Pradesh', 'Krishna', 'Government', 250, '["ICU","Ambulance","Pharmacy","Diagnostics","24/7 Emergency","OPD","Maternity"]'::jsonb,
  '[{"name":"General Medicine","specialist":"Dr. D. S. R. Murthy","phone":null},{"name":"Orthopaedics","specialist":"Dr. G. Phani Kumar","phone":null}]'::jsonb),

-- Tirupati / Chittoor
('Ruia Government General Hospital', 'General medicine', 'Alipiri Road, Tirupati', '0877-2282200', true, 'Tirupati', 'Andhra Pradesh', 'Chittoor', 'Government', 500, '["ICU","Ambulance","Pharmacy","Diagnostics","24/7 Emergency","OPD","Maternity Ward","Surgery","Blood Bank","Cafeteria"]'::jsonb,
  '[{"name":"General Medicine","specialist":"Dr. C. Ramesh","phone":"0877-2282200"},{"name":"Cardiology","specialist":"Dr. P. Ranganath","phone":null},{"name":"Neurology","specialist":"Dr. S. Anitha","phone":null},{"name":"Pediatrics","specialist":"Dr. R. Sridevi","phone":null}]'::jsonb),
('Maternity Hospital (Government), Tirupati', 'Gynaecology', 'Korlagunta, Tirupati', '0877-2235566', true, 'Tirupati', 'Andhra Pradesh', 'Chittoor', 'Government', 200, '["ICU","Pharmacy","Diagnostics","24/7 Emergency","Maternity Ward","Neonatal Care"]'::jsonb,
  '[{"name":"Gynaecology","specialist":"Dr. V. Lakshmi","phone":null},{"name":"Pediatrics (Neonatal)","specialist":"Dr. N. Sujatha","phone":null}]'::jsonb),
('Sri Venkateswara Ram Naidu Charitable Trust Hospital', 'General medicine', 'Renigunta Road, Tirupati', '0877-2266888', false, 'Tirupati', 'Andhra Pradesh', 'Chittoor', 'Private', 80, '["OPD","Pharmacy","Diagnostics","Charitable Ward","Free OPD"]'::jsonb,
  '[{"name":"General Medicine","specialist":"Dr. S. Ram Naidu","phone":null}]'::jsonb),

-- Chittoor
('Chittoor Government Hospital', 'General medicine', 'Old Town, Chittoor', '08572-222500', true, 'Chittoor', 'Andhra Pradesh', 'Chittoor', 'Government', 300, '["ICU","Ambulance","Pharmacy","Diagnostics","24/7 Emergency","OPD","Maternity"]'::jsonb,
  '[{"name":"General Medicine","specialist":"Dr. M. Suresh Babu","phone":null},{"name":"Pediatrics","specialist":"Dr. P. Anitha","phone":null}]'::jsonb),

-- Visakhapatnam
('Government ENT Hospital, Visakhapatnam', 'ENT', 'Suryabagh, Visakhapatnam', '0891-2564333', false, 'Visakhapatnam', 'Andhra Pradesh', 'Visakhapatnam', 'Government', 80, '["OPD","Pharmacy","Diagnostics","ENT Surgery"]'::jsonb,
  '[{"name":"ENT","specialist":"Dr. P. V. R. Murthy","phone":"0891-2564333"}]'::jsonb),
('Government Victoria Hospital (Maternity), Visakhapatnam', 'Gynaecology', 'Kothavasala, Visakhapatnam', '0891-2756677', true, 'Visakhapatnam', 'Andhra Pradesh', 'Visakhapatnam', 'Government', 200, '["ICU","Pharmacy","Diagnostics","24/7 Emergency","Maternity Ward","Neonatal Care"]'::jsonb,
  '[{"name":"Gynaecology","specialist":"Dr. P. Sailaja","phone":null},{"name":"Pediatrics (Neonatal)","specialist":"Dr. K. Usha","phone":null}]'::jsonb),
('ESI Hospital, Visakhapatnam', 'General medicine', 'Seethammadhara, Visakhapatnam', '0891-2735000', true, 'Visakhapatnam', 'Andhra Pradesh', 'Visakhapatnam', 'Government', 250, '["ICU","Pharmacy","Diagnostics","24/7 Emergency","OPD"]'::jsonb,
  '[{"name":"General Medicine","specialist":"Dr. V. Appa Rao","phone":null},{"name":"Orthopaedics","specialist":"Dr. S. Priyanka","phone":null}]'::jsonb),
('Sankara Netralaya (Charitable), Visakhapatnam', 'Ophthalmology', 'Pandurangapuram, Visakhapatnam', '0891-2785555', false, 'Visakhapatnam', 'Andhra Pradesh', 'Visakhapatnam', 'Private', 60, '["OPD","Pharmacy","Diagnostics","Eye Surgery","Charitable Ward"]'::jsonb,
  '[{"name":"Ophthalmology","specialist":"Dr. R. N. Ravi","phone":null}]'::jsonb),

-- Anakapalli
('Anakapalli Government Hospital', 'General medicine', 'Old Town, Anakapalle', '08924-222100', true, 'Anakapalle', 'Andhra Pradesh', 'Visakhapatnam', 'Government', 200, '["ICU","Ambulance","Pharmacy","Diagnostics","24/7 Emergency","OPD","Maternity"]'::jsonb,
  '[{"name":"General Medicine","specialist":"Dr. K. Phani Kumar","phone":null}]'::jsonb),

-- Narsaraopeta
('Government Area Hospital, Narsaraopeta', 'General medicine', 'Main Road, Narsaraopeta', '08684-222300', true, 'Narsaraopeta', 'Andhra Pradesh', 'Guntur', 'Government', 150, '["ICU","Ambulance","Pharmacy","Diagnostics","24/7 Emergency","OPD","Maternity"]'::jsonb,
  '[{"name":"General Medicine","specialist":"Dr. S. S. Prasad","phone":null}]'::jsonb)
ON CONFLICT DO NOTHING;
