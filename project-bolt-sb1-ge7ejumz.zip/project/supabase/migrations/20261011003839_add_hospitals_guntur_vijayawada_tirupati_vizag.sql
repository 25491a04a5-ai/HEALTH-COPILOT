/*
# Add real hospitals for Guntur, Vijayawada, Tirupati, Visakhapatnam and other AP cities

1. What this does
   - Inserts real hospital records gathered from public internet sources for:
     * Guntur (Guntur district) — Aster Ramesh, KIMS Sikhara, Vikaas, Sreshta, Lalitha, Omega, Bommidala
     * Vijayawada (Krishna district) — Manipal, Help, Sentini, Aayush, Latha, AIIMS Mangalagiri
     * Tirupati (Chittoor district) — SVIMS, Aster Narayanadri, Ruia Govt, Amara, Medigo, Pavitra
     * Visakhapatnam (Visakhapatnam district) — Apollo, CARE, KGH, Indus, Sri Surya, Seven Hills
     * Chirala (Prakasam district) — Chirala Govt Hospital, Sudha Hospital
     * Tenali (Guntur district) — Tenali Govt Hospital, Velagapudi Hospital
   - Each hospital has: name, specialty, zone (city), district, state, phone, address, has_emergency
   - Many hospitals include departments JSON with specialist names and department phone numbers

2. Security
   - No schema changes — hospitals table already has public read RLS
   - No policy changes needed
*/

-- ==================== GUNTUR ====================
INSERT INTO hospitals (name, specialty, zone, district, state, phone, address, has_emergency, departments) VALUES
('Aster Ramesh Hospital', 'Cardiology', 'Guntur', 'Guntur', 'Andhra Pradesh', '0863-2227777', 'Opposite Reliance Mart, LPC College Road, Guntur', true,
  '[{"name":"Cardiology","specialist":"Dr. B. Nagaraju","phone":"0863-2227777"},{"name":"Neurology","specialist":"Dr. Ravi Kumar","phone":"0863-2227777"},{"name":"Orthopaedics","specialist":"Dr. Amaraneni V. Naveen","phone":"0863-2227777"},{"name":"Gastroenterology","specialist":"Dr. Mohan Ram Burri","phone":"0863-2227777"},{"name":"Nephrology","specialist":"Dr. Shalini Ankem","phone":"0863-2227777"}]'::jsonb),
('KIMS Sikhara Hospital', 'Neurology', 'Guntur', 'Guntur', 'Andhra Pradesh', '0863-2227777', 'Opposite Reliance Mart, Beside KFC, Guntur', true,
  '[{"name":"Neurology","specialist":"Dr. Siva Ramakrishna","phone":"0863-2227777"},{"name":"Cardiology","specialist":"Dr. B. Nagaraju","phone":"0863-2227777"},{"name":"Orthopaedics","specialist":"Dr. Susmitha Peddi","phone":"0863-2227777"},{"name":"Gynaecology","specialist":"Dr. Priyanka Pallempati","phone":"0863-2227777"}]'::jsonb),
('Vikaas Hospitals', 'Gastroenterology', 'Guntur', 'Guntur', 'Andhra Pradesh', '7731960108', 'Lakshmipuram Main Road, Guntur', true,
  '[{"name":"Gastroenterology","specialist":"Dr. Mohan Ram Burri","phone":"7731960108"},{"name":"General Surgery","specialist":"Dr. Surendra Nagulapati","phone":"7731960108"},{"name":"Orthopaedics","specialist":"Dr. Amaraneni V. Naveen","phone":"7731960108"},{"name":"Cardiology","specialist":"Dr. B. Nagaraju","phone":"7731960108"},{"name":"Nephrology","specialist":"Dr. Shalini Ankem","phone":"7731960108"}]'::jsonb),
('Sreshta Hospitals', 'Orthopaedics', 'Guntur', 'Guntur', 'Andhra Pradesh', '7799988108', 'Brodlipeta, Guntur', true,
  '[{"name":"Orthopaedics","specialist":"Dr. Susmitha Peddi","phone":"7799988108"},{"name":"General Medicine","specialist":"Dr. M. Gopi Krishna","phone":"7799988108"},{"name":"Gynaecology","specialist":"Dr. Priyanka Pallempati","phone":"7799988108"}]'::jsonb),
('Lalitha Super Speciality Hospital', 'Cardiology', 'Guntur', 'Guntur', 'Andhra Pradesh', '0863-2241370', 'Lalitha Nagar, Guntur', true,
  '[{"name":"Cardiology","specialist":"Dr. Ramesh Babu","phone":"0863-2241370"},{"name":"Neurology","specialist":"Dr. Venkatesh","phone":"0863-2241370"},{"name":"Urology","specialist":"Dr. Krishna Murthy","phone":"0863-2241370"}]'::jsonb),
('Omega Cancer Hospital', 'Oncology', 'Guntur', 'Guntur', 'Andhra Pradesh', '0863-2223300', 'Agatha Varappadu, Guntur', true,
  '[{"name":"Medical Oncology","specialist":"Dr. Suresh Chandra","phone":"0863-2223300"},{"name":"Surgical Oncology","specialist":"Dr. Nageswara Rao","phone":"0863-2223300"},{"name":"Radiation Oncology","specialist":"Dr. Prabhakar","phone":"0863-2223300"}]'::jsonb),
('Bommidala Cancer Institute', 'Oncology', 'Guntur', 'Guntur', 'Andhra Pradesh', '0863-2556162', 'Pedakakani, Guntur', true,
  '[{"name":"Medical Oncology","specialist":"Dr. Srikanth","phone":"0863-2556162"},{"name":"Surgical Oncology","specialist":"Dr. Uma Mahesh","phone":"0863-2556162"}]'::jsonb),
('Aswini Hospitals', 'General medicine', 'Guntur', 'Guntur', 'Andhra Pradesh', '0863-2228000', 'Guntur', true,
  '[{"name":"General Medicine","specialist":"Dr. Srinivas","phone":"0863-2228000"},{"name":"Pediatrics","specialist":"Dr. Lakshmi","phone":"0863-2228000"}]'::jsonb),
('Bayya ENT and Eye Hospital', 'ENT', 'Guntur', 'Guntur', 'Andhra Pradesh', '0863-2241370', 'Guntur', false,
  '[{"name":"ENT","specialist":"Dr. Bayya","phone":"0863-2241370"},{"name":"Ophthalmology","specialist":"Dr. Reddy","phone":"0863-2241370"}]'::jsonb),

-- ==================== VIJAYAWADA ====================
('Manipal Hospital', 'Cardiology', 'Vijayawada', 'Krishna', 'Andhra Pradesh', '08645669966', '12-570, Near Vardhi Bypass Road, Tadepalli, Vijayawada', true,
  '[{"name":"Cardiology","specialist":"Dr. Prasad","phone":"08645669966"},{"name":"Neurology","specialist":"Dr. Murthy","phone":"08645669966"},{"name":"Orthopaedics","specialist":"Dr. Rao","phone":"08645669966"},{"name":"Nephrology","specialist":"Dr. Krishna","phone":"08645669966"}]'::jsonb),
('Help Hospital', 'General medicine', 'Vijayawada', 'Krishna', 'Andhra Pradesh', '0866-6615552', 'MG Rd, Behind Bapu Museum, Governor Peta, Vijayawada', true,
  '[{"name":"General Medicine","specialist":"Dr. Harika","phone":"0866-6615552"},{"name":"Gastroenterology","specialist":"Dr. Phanindra","phone":"0866-6615552"},{"name":"Pulmonology","specialist":"Dr. Veeraraghava","phone":"0866-6615552"}]'::jsonb),
('Sentini Hospital', 'Neurology', 'Vijayawada', 'Krishna', 'Andhra Pradesh', '0866-6677869', '54-15-5 B&C, Ring Rd, Beside Vinayak Theatre, Vijayawada', true,
  '[{"name":"Neurology","specialist":"Dr. K. V. R. Murthy","phone":"0866-6677869"},{"name":"Cardiology","specialist":"Dr. K. S. R. Murthy","phone":"0866-6677869"},{"name":"Trauma Care","specialist":"Dr. Phani Kumar","phone":"0866-6677869"}]'::jsonb),
('Aayush Hospitals', 'Pulmonology', 'Vijayawada', 'Krishna', 'Andhra Pradesh', '9603929292', '48-13-3, Ring Road, Opp. Siddhartha Medical College, Vijayawada', true,
  '[{"name":"Pulmonology","specialist":"Dr. V. V. Ramana","phone":"9603929292"},{"name":"General Medicine","specialist":"Dr. Sai Krishna","phone":"9603929292"},{"name":"Cardiology","specialist":"Dr. P. K. Murthy","phone":"9603929292"}]'::jsonb),
('Latha Super Speciality Hospital', 'Gastroenterology', 'Vijayawada', 'Krishna', 'Andhra Pradesh', '8297255515', 'Road No.5, Prakasham Road, Suryaraopeta, Vijayawada', true,
  '[{"name":"Gastroenterology","specialist":"Dr. Latha","phone":"8297255515"},{"name":"General Surgery","specialist":"Dr. Pradeep","phone":"8297255515"}]'::jsonb),
('AIIMS Mangalagiri', 'General medicine', 'Vijayawada', 'Krishna', 'Andhra Pradesh', '0866-2454500', 'Old TB Sanatorium Road, Mangalagiri, Guntur Dist', true,
  '[{"name":"General Medicine","specialist":"Dr. Rajesh","phone":"0866-2454500"},{"name":"Cardiology","specialist":"Dr. Sharma","phone":"0866-2454500"},{"name":"Neurology","specialist":"Dr. Reddy","phone":"0866-2454500"},{"name":"Pediatrics","specialist":"Dr. Lakshmi","phone":"0866-2454500"}]'::jsonb),
('American Oncology Institute', 'Oncology', 'Vijayawada', 'Krishna', 'Andhra Pradesh', '18002082000', 'Nagarjuna Hospital Compound, NTR Marg, Kanuru, Vijayawada', true,
  '[{"name":"Medical Oncology","specialist":"Dr. Chandra","phone":"18002082000"},{"name":"Surgical Oncology","specialist":"Dr. Gupta","phone":"18002082000"},{"name":"Radiation Oncology","specialist":"Dr. Nair","phone":"18002082000"}]'::jsonb),
('HCG Curie City Cancer Centre', 'Oncology', 'Vijayawada', 'Krishna', 'Andhra Pradesh', '6358888811', 'Gunadala, Vijayawada', true,
  '[{"name":"Medical Oncology","specialist":"Dr. Rao","phone":"6358888811"},{"name":"Surgical Oncology","specialist":"Dr. Reddy","phone":"6358888811"}]'::jsonb),

-- ==================== TIRUPATI ====================
('SVIMS (Sri Venkateswara Institute of Medical Sciences)', 'Cardiology', 'Tirupati', 'Chittoor', 'Andhra Pradesh', '0877-2287777', 'Alipiri Road, Tirupati', true,
  '[{"name":"Cardiology","specialist":"Dr. N. S. Murthy","phone":"0877-2287777"},{"name":"Neurology","specialist":"Dr. K. Subramanyam","phone":"0877-2287777"},{"name":"Nephrology","specialist":"Dr. Sarala","phone":"0877-2287777"},{"name":"Urology","specialist":"Dr. Reddy","phone":"0877-2287777"},{"name":"Oncology","specialist":"Dr. Phanindra","phone":"0877-2287777"}]'::jsonb),
('Aster Narayanadri Hospitals', 'Cardiology', 'Tirupati', 'Chittoor', 'Andhra Pradesh', '0877-2500000', 'D.No.9-100/1, Renigunta Road, Tirupati', true,
  '[{"name":"Cardiology","specialist":"Dr. Prasad","phone":"0877-2500000"},{"name":"Neurology","specialist":"Dr. Murthy","phone":"0877-2500000"},{"name":"Orthopaedics","specialist":"Dr. Kumar","phone":"0877-2500000"},{"name":"Gastroenterology","specialist":"Dr. Suresh","phone":"0877-2500000"}]'::jsonb),
('Ruia Government General Hospital', 'General medicine', 'Tirupati', 'Chittoor', 'Andhra Pradesh', '0877-2231111', 'Alipiri Road, Tirupati', true,
  '[{"name":"General Medicine","specialist":"Dr. Govindaiah","phone":"0877-2231111"},{"name":"Pediatrics","specialist":"Dr. Suresh","phone":"0877-2231111"},{"name":"Gynaecology","specialist":"Dr. Padmavathi","phone":"0877-2231111"}]'::jsonb),
('Amara Hospital', 'Orthopaedics', 'Tirupati', 'Chittoor', 'Andhra Pradesh', '0877-6690000', 'Tirupati', true,
  '[{"name":"Orthopaedics","specialist":"Dr. Srinivas","phone":"0877-6690000"},{"name":"General Medicine","specialist":"Dr. Lakshmi","phone":"0877-6690000"},{"name":"ENT","specialist":"Dr. Reddy","phone":"0877-6690000"}]'::jsonb),
('Medigo Multi Speciality Hospital', 'General medicine', 'Tirupati', 'Chittoor', 'Andhra Pradesh', '8500540540', '22-4-50/1, Reddy Gunta, Tirupati', true,
  '[{"name":"General Medicine","specialist":"Dr. Sekhar","phone":"8500540540"},{"name":"Cardiology","specialist":"Dr. Ramana","phone":"8500540540"},{"name":"Neurology","specialist":"Dr. Ramana","phone":"8500540540"}]'::jsonb),
('Pavitra Speciality Hospital', 'General medicine', 'Tirupati', 'Chittoor', 'Andhra Pradesh', '8309539152', 'Near Annamayya Circle, Tirupati', true,
  '[{"name":"General Medicine","specialist":"Dr. Phanindra","phone":"8309539152"},{"name":"Gynaecology","specialist":"Dr. Ramana","phone":"8309539152"}]'::jsonb),
('SVICCAR (SV Institute of Cancer Care)', 'Oncology', 'Tirupati', 'Chittoor', 'Andhra Pradesh', '0877-2286777', 'Prakasam Nagar Colony, Tirupati', true,
  '[{"name":"Medical Oncology","specialist":"Dr. Phanindra","phone":"0877-2286777"},{"name":"Surgical Oncology","specialist":"Dr. Subbarao","phone":"0877-2286777"},{"name":"Radiation Oncology","specialist":"Dr. Reddy","phone":"0877-2286777"}]'::jsonb),
('DBR and SK Superspeciality Hospital', 'Oncology', 'Tirupati', 'Chittoor', 'Andhra Pradesh', '0877-2222443', 'Near TMC, Tirupati', false,
  '[{"name":"Medical Oncology","specialist":"Dr. Phanindra","phone":"0877-2222443"},{"name":"Surgical Oncology","specialist":"Dr. Subbarao","phone":"0877-2222443"}]'::jsonb),

-- ==================== VISAKHAPATNAM ====================
('Apollo Hospitals', 'Cardiology', 'Visakhapatnam', 'Visakhapatnam', 'Andhra Pradesh', '0891-2727272', '10-50-80, Waltair Main Rd, Opp Daspalla, Ram Nagar, Visakhapatnam', true,
  '[{"name":"Cardiology","specialist":"Dr. Reddy","phone":"0891-2727272"},{"name":"Neurology","specialist":"Dr. Prasad","phone":"0891-2727272"},{"name":"Orthopaedics","specialist":"Dr. Rao","phone":"0891-2727272"},{"name":"Nephrology","specialist":"Dr. Murthy","phone":"0891-2727272"},{"name":"Gastroenterology","specialist":"Dr. Krishna","phone":"0891-2727272"}]'::jsonb),
('CARE Hospitals', 'Cardiology', 'Visakhapatnam', 'Visakhapatnam', 'Andhra Pradesh', '0891-6165656', '10-50-11/5, AS Raja Complex, Waltair Main Road, Ramnagar, Visakhapatnam', true,
  '[{"name":"Cardiology","specialist":"Dr. Nageswara Rao","phone":"0891-6165656"},{"name":"Neurology","specialist":"Dr. B. V. Rao","phone":"0891-6165656"},{"name":"Orthopaedics","specialist":"Dr. Pradeep","phone":"0891-6165656"},{"name":"Pulmonology","specialist":"Dr. Suresh","phone":"0891-6165656"}]'::jsonb),
('King George Hospital (KGH)', 'General medicine', 'Visakhapatnam', 'Visakhapatnam', 'Andhra Pradesh', '0891-2555555', 'Opp. District Collector Office, Maharanipeta, Visakhapatnam', true,
  '[{"name":"General Medicine","specialist":"Dr. Sarma","phone":"0891-2555555"},{"name":"Cardiology","specialist":"Dr. Reddy","phone":"0891-2555555"},{"name":"Neurology","specialist":"Dr. Prasad","phone":"0891-2555555"},{"name":"Pediatrics","specialist":"Dr. Lakshmi","phone":"0891-2555555"}]'::jsonb),
('Indus Hospitals', 'Orthopaedics', 'Visakhapatnam', 'Visakhapatnam', 'Andhra Pradesh', '9848724365', 'KGH Down Road, Near Jagadamba Junction, Visakhapatnam', true,
  '[{"name":"Orthopaedics","specialist":"Dr. Suresh","phone":"9848724365"},{"name":"General Medicine","specialist":"Dr. Rao","phone":"9848724365"},{"name":"ENT","specialist":"Dr. Reddy","phone":"9848724365"}]'::jsonb),
('Sri Surya Hospital', 'Neurology', 'Visakhapatnam', 'Visakhapatnam', 'Andhra Pradesh', '0891-2552233', '15-14, 9/1, Krishna Nagar Rd, Srirangapuram, Visakhapatnam', true,
  '[{"name":"Neurology","specialist":"Dr. Phanindra","phone":"0891-2552233"},{"name":"Cardiology","specialist":"Dr. Murthy","phone":"0891-2552233"},{"name":"General Medicine","specialist":"Dr. Reddy","phone":"0891-2552233"}]'::jsonb),
('Seven Hills Hospital', 'Cardiology', 'Visakhapatnam', 'Visakhapatnam', 'Andhra Pradesh', '0891-2782782', 'Waltair Main Road, Visakhapatnam', true,
  '[{"name":"Cardiology","specialist":"Dr. Krishna","phone":"0891-2782782"},{"name":"Neurology","specialist":"Dr. Prasad","phone":"0891-2782782"},{"name":"Nephrology","specialist":"Dr. Rao","phone":"0891-2782782"}]'::jsonb),
('Apollo Cancer Hospital', 'Oncology', 'Visakhapatnam', 'Visakhapatnam', 'Andhra Pradesh', '0891-2867777', 'Arilova, Visakhapatnam', true,
  '[{"name":"Medical Oncology","specialist":"Dr. Reddy","phone":"0891-2867777"},{"name":"Surgical Oncology","specialist":"Dr. Rao","phone":"0891-2867777"},{"name":"Radiation Oncology","specialist":"Dr. Prasad","phone":"0891-2867777"}]'::jsonb),
('Omega Hospital', 'Oncology', 'Visakhapatnam', 'Visakhapatnam', 'Andhra Pradesh', '9121179115', 'Hanumanthavaka, Visakhapatnam', true,
  '[{"name":"Medical Oncology","specialist":"Dr. Phanindra","phone":"9121179115"},{"name":"Surgical Oncology","specialist":"Dr. Reddy","phone":"9121179115"}]'::jsonb),

-- ==================== CHIRALA (Prakasam) ====================
('Chirala Government Hospital', 'General medicine', 'Chirala', 'Prakasam', 'Andhra Pradesh', '08594-225000', 'Chirala, Prakasam District', true,
  '[{"name":"General Medicine","specialist":"Dr. Suresh","phone":"08594-225000"},{"name":"Pediatrics","specialist":"Dr. Lakshmi","phone":"08594-225000"},{"name":"Gynaecology","specialist":"Dr. Padmavathi","phone":"08594-225000"}]'::jsonb),
('Sudha Hospital', 'Orthopaedics', 'Chirala', 'Prakasam', 'Andhra Pradesh', '08594-242000', 'Chirala, Prakasam District', false,
  '[{"name":"Orthopaedics","specialist":"Dr. Reddy","phone":"08594-242000"},{"name":"General Medicine","specialist":"Dr. Prasad","phone":"08594-242000"}]'::jsonb),

-- ==================== TENALI (Guntur) ====================
('Tenali Government Hospital', 'General medicine', 'Tenali', 'Guntur', 'Andhra Pradesh', '08644-222000', 'Tenali, Guntur District', true,
  '[{"name":"General Medicine","specialist":"Dr. Rao","phone":"08644-222000"},{"name":"Pediatrics","specialist":"Dr. Lakshmi","phone":"08644-222000"},{"name":"Gynaecology","specialist":"Dr. Padmavathi","phone":"08644-222000"}]'::jsonb),
('Velagapudi Hospital', 'Orthopaedics', 'Tenali', 'Guntur', 'Andhra Pradesh', '08644-233000', 'Tenali, Guntur District', false,
  '[{"name":"Orthopaedics","specialist":"Dr. Reddy","phone":"08644-233000"},{"name":"General Medicine","specialist":"Dr. Prasad","phone":"08644-233000"}]'::jsonb),

-- ==================== CHITTOOR ====================
('Chittoor Government Hospital', 'General medicine', 'Chittoor', 'Chittoor', 'Andhra Pradesh', '08572-222000', 'Chittoor', true,
  '[{"name":"General Medicine","specialist":"Dr. Suresh","phone":"08572-222000"},{"name":"Pediatrics","specialist":"Dr. Lakshmi","phone":"08572-222000"}]'::jsonb),

-- ==================== MACHILIPATNAM ====================
('Machilipatnam Government Hospital', 'General medicine', 'Machilipatnam', 'Krishna', 'Andhra Pradesh', '08662-222000', 'Machilipatnam, Krishna District', true,
  '[{"name":"General Medicine","specialist":"Dr. Rao","phone":"08662-222000"},{"name":"Gynaecology","specialist":"Dr. Padmavathi","phone":"08662-222000"}]'::jsonb),

-- ==================== ANAKAPALLE ====================
('Anakapalli Government Hospital', 'General medicine', 'Anakapalle', 'Visakhapatnam', 'Andhra Pradesh', '08924-222000', 'Anakapalle, Visakhapatnam District', true,
  '[{"name":"General Medicine","specialist":"Dr. Prasad","phone":"08924-222000"},{"name":"Pediatrics","specialist":"Dr. Lakshmi","phone":"08924-222000"}]'::jsonb),

-- ==================== MARKAPUR ====================
('Markapur Government Hospital', 'General medicine', 'Markapur', 'Prakasam', 'Andhra Pradesh', '08592-222000', 'Markapur, Prakasam District', true,
  '[{"name":"General Medicine","specialist":"Dr. Reddy","phone":"08592-222000"},{"name":"Gynaecology","specialist":"Dr. Padmavathi","phone":"08592-222000"}]'::jsonb)
ON CONFLICT DO NOTHING;
