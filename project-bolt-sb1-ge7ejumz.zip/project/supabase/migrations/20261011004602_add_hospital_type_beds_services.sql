/*
# Add hospital type, bed count, and services columns

1. What this does
   - Adds `hospital_type` column (text) to classify hospitals as Government / Private / Super Speciality / Cancer
   - Adds `beds` column (int) for bed capacity
   - Adds `services` column (jsonb array of strings) for additional services like ambulance, pharmacy, ICU, etc.
   - Updates existing hospitals with appropriate values

2. Security
   - No policy changes — hospitals table remains public read
*/

ALTER TABLE hospitals
  ADD COLUMN IF NOT EXISTS hospital_type text DEFAULT 'Private';

ALTER TABLE hospitals
  ADD COLUMN IF NOT EXISTS beds int;

ALTER TABLE hospitals
  ADD COLUMN IF NOT EXISTS services jsonb DEFAULT '[]'::jsonb;

-- Classify existing hospitals
UPDATE hospitals SET hospital_type = 'Government' WHERE name ILIKE '%government%' OR name ILIKE '%govt%' OR name ILIKE '%ruia%' OR name ILIKE '%KGH%' OR name ILIKE '%AIIMS%' OR name ILIKE '%SVIMS%';
UPDATE hospitals SET hospital_type = 'Super Speciality' WHERE name ILIKE '%super special%' OR name ILIKE '%aster%' OR name ILIKE '%kims%' OR name ILIKE '%manipal%' OR name ILIKE '%apollo%' OR name ILIKE '%care%' OR name ILIKE '%vikaas%';
UPDATE hospitals SET hospital_type = 'Cancer' WHERE name ILIKE '%cancer%' OR name ILIKE '%oncology%' OR name ILIKE '%SVICCAR%' OR name ILIKE '%HCG%';

-- Bed counts for known hospitals
UPDATE hospitals SET beds = 350 WHERE name = 'Aster Ramesh Hospital' AND zone = 'Guntur';
UPDATE hospitals SET beds = 200 WHERE name = 'KIMS Sikhara Hospital' AND zone = 'Guntur';
UPDATE hospitals SET beds = 150 WHERE name = 'Vikaas Hospitals' AND zone = 'Guntur';
UPDATE hospitals SET beds = 80 WHERE name = 'Sreshta Hospitals' AND zone = 'Guntur';
UPDATE hospitals SET beds = 100 WHERE name = 'Lalitha Super Speciality Hospital' AND zone = 'Guntur';
UPDATE hospitals SET beds = 120 WHERE name = 'Omega Cancer Hospital' AND zone = 'Guntur';
UPDATE hospitals SET beds = 100 WHERE name = 'Bommidala Cancer Institute' AND zone = 'Guntur';
UPDATE hospitals SET beds = 750 WHERE name ILIKE 'AIIMS Mangalagiri%';
UPDATE hospitals SET beds = 500 WHERE name = 'Manipal Hospital' AND zone = 'Vijayawada';
UPDATE hospitals SET beds = 200 WHERE name = 'Help Hospital' AND zone = 'Vijayawada';
UPDATE hospitals SET beds = 150 WHERE name = 'Sentini Hospital' AND zone = 'Vijayawada';
UPDATE hospitals SET beds = 100 WHERE name = 'Aayush Hospitals' AND zone = 'Vijayawada';
UPDATE hospitals SET beds = 80 WHERE name = 'Latha Super Speciality Hospital' AND zone = 'Vijayawada';
UPDATE hospitals SET beds = 200 WHERE name ILIKE 'American Oncology%';
UPDATE hospitals SET beds = 150 WHERE name = 'HCG Curie City Cancer Centre' AND zone = 'Vijayawada';
UPDATE hospitals SET beds = 900 WHERE name ILIKE 'SVIMS%';
UPDATE hospitals SET beds = 300 WHERE name = 'Aster Narayanadri Hospitals' AND zone = 'Tirupati';
UPDATE hospitals SET beds = 500 WHERE name ILIKE 'Ruia Government%';
UPDATE hospitals SET beds = 100 WHERE name = 'Amara Hospital' AND zone = 'Tirupati';
UPDATE hospitals SET beds = 50 WHERE name = 'Medigo Multi Speciality Hospital' AND zone = 'Tirupati';
UPDATE hospitals SET beds = 50 WHERE name = 'Pavitra Speciality Hospital' AND zone = 'Tirupati';
UPDATE hospitals SET beds = 200 WHERE name ILIKE 'SVICCAR%';
UPDATE hospitals SET beds = 50 WHERE name ILIKE 'DBR and SK%';
UPDATE hospitals SET beds = 500 WHERE name = 'Apollo Hospitals' AND zone = 'Visakhapatnam';
UPDATE hospitals SET beds = 250 WHERE name = 'CARE Hospitals' AND zone = 'Visakhapatnam';
UPDATE hospitals SET beds = 1000 WHERE name ILIKE 'King George Hospital%';
UPDATE hospitals SET beds = 80 WHERE name = 'Indus Hospitals' AND zone = 'Visakhapatnam';
UPDATE hospitals SET beds = 100 WHERE name = 'Sri Surya Hospital' AND zone = 'Visakhapatnam';
UPDATE hospitals SET beds = 300 WHERE name = 'Seven Hills Hospital' AND zone = 'Visakhapatnam';
UPDATE hospitals SET beds = 200 WHERE name = 'Apollo Cancer Hospital' AND zone = 'Visakhapatnam';
UPDATE hospitals SET beds = 150 WHERE name = 'Omega Hospital' AND zone = 'Visakhapatnam';
UPDATE hospitals SET beds = 200 WHERE name ILIKE 'Chirala Government%';
UPDATE hospitals SET beds = 50 WHERE name = 'Sudha Hospital' AND zone = 'Chirala';
UPDATE hospitals SET beds = 300 WHERE name ILIKE 'Tenali Government%';
UPDATE hospitals SET beds = 30 WHERE name = 'Velagapudi Hospital' AND zone = 'Tenali';
UPDATE hospitals SET beds = 300 WHERE name ILIKE 'Chittoor Government%';
UPDATE hospitals SET beds = 250 WHERE name ILIKE 'Machilipatnam Government%';
UPDATE hospitals SET beds = 200 WHERE name ILIKE 'Anakapalli Government%';
UPDATE hospitals SET beds = 150 WHERE name ILIKE 'Markapur Government%';
UPDATE hospitals SET beds = 30 WHERE name = 'Aswini Hospitals' AND zone = 'Guntur';
UPDATE hospitals SET beds = 20 WHERE name = 'Bayya ENT and Eye Hospital' AND zone = 'Guntur';

-- Services for hospitals
UPDATE hospitals SET services = '["ICU","Ambulance","Pharmacy","Diagnostics","24/7 Emergency","Cafeteria"]'::jsonb WHERE has_emergency = true AND hospital_type IN ('Super Speciality', 'Government');
UPDATE hospitals SET services = '["ICU","Ambulance","Pharmacy","Diagnostics","24/7 Emergency"]'::jsonb WHERE has_emergency = true AND hospital_type = 'Private';
UPDATE hospitals SET services = '["Pharmacy","Diagnostics","OPD"]'::jsonb WHERE has_emergency = false AND services = '[]'::jsonb;
UPDATE hospitals SET services = '["ICU","Ambulance","Pharmacy","Diagnostics","24/7 Emergency","Chemotherapy","Radiation Therapy"]'::jsonb WHERE hospital_type = 'Cancer';
