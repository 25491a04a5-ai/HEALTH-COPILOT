/*
# Add state, district, and departments to hospitals

1. Changes
  - Adds `state` column (text, default 'Andhra Pradesh') to hospitals table
  - Adds `district` column (text, nullable) to hospitals table
  - Adds `departments` column (jsonb, nullable) to hospitals table
    - Stores array of {name, specialist, phone} objects for each hospital's departments

2. Security
  - No policy changes — hospitals remains public read (anon + authenticated)
*/

ALTER TABLE hospitals
  ADD COLUMN IF NOT EXISTS state text NOT NULL DEFAULT 'Andhra Pradesh';

ALTER TABLE hospitals
  ADD COLUMN IF NOT EXISTS district text;

ALTER TABLE hospitals
  ADD COLUMN IF NOT EXISTS departments jsonb DEFAULT '[]'::jsonb;

-- Update existing hospitals with district based on zone
UPDATE hospitals SET district = 'Prakasam' WHERE zone = 'Ongole' AND district IS NULL;
UPDATE hospitals SET district = 'Guntur' WHERE zone = 'Guntur' AND district IS NULL;
UPDATE hospitals SET district = 'Guntur' WHERE zone = 'Narsaraopeta' AND district IS NULL;
