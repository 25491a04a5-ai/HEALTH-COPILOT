/*
# Add file_url column to patient_reports

1. Changes
  - Adds nullable `file_url` column to `patient_reports` for storing uploaded file paths in Supabase Storage
  - Creates `report_files` storage bucket (private, max 20 MB per file, PDF/image types)
  - RLS policies: only the report owner can upload/download their own files

2. Security
  - Bucket is private (not public)
  - Storage policies scope access to auth.uid() matching the folder prefix
*/

ALTER TABLE patient_reports
  ADD COLUMN IF NOT EXISTS file_url text;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'report-files',
  'report-files',
  false,
  20971520,
  ARRAY['application/pdf','image/jpeg','image/png','image/webp','image/gif']
)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "owner_upload_report_files" ON storage.objects;
CREATE POLICY "owner_upload_report_files" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'report-files'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

DROP POLICY IF EXISTS "owner_select_report_files" ON storage.objects;
CREATE POLICY "owner_select_report_files" ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'report-files'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

DROP POLICY IF EXISTS "owner_delete_report_files" ON storage.objects;
CREATE POLICY "owner_delete_report_files" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'report-files'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );
