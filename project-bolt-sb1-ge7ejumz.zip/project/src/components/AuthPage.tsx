import { useState, FormEvent } from 'react';
import { Heart, Mail, Lock, User, Eye, EyeOff, Activity, ShieldCheck, Droplet, Globe } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useLang } from '@/context/LangContext';
import { LANGS, Lang } from '@/lib/i18n';

function friendlyError(msg: string, t: (k: string) => string): string {
  const m = msg.toLowerCase();
  if (m.includes('invalid login')) return t('err_invalid');
  if (m.includes('not confirmed')) return t('err_not_confirmed');
  if (m.includes('already registered')) return t('err_exists');
  if (m.includes('api key')) return t('err_api_key');
  return msg;
}

export default function AuthPage() {
  const { signIn, signUp, signInWithGoogle } = useAuth();
  const { lang, setLang, t } = useLang();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [msg, setMsg] = useState('');
  const [isError, setIsError] = useState(false);
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setMsg('');
    setIsError(false);
    setBusy(true);

    if (mode === 'signup') {
      const { error, needsConfirmation } = await signUp(email, password, fullName);
      if (error) {
        setMsg(friendlyError(error, t));
        setIsError(true);
      } else if (needsConfirmation) {
        setMsg(t('account_created'));
      }
    } else {
      const { error } = await signIn(email, password);
      if (error) {
        setMsg(friendlyError(error, t));
        setIsError(true);
      }
    }
    setBusy(false);
  }

  const [googleLoading, setGoogleLoading] = useState(false);

  async function handleGoogle() {
    setMsg('');
    setIsError(false);
    setGoogleLoading(true);
    const { error } = await signInWithGoogle();
    if (error) {
      const errKey = error === 'No OAuth URL returned' ? 'err_google_no_url' : '';
      setMsg(t('err_google') + (errKey ? t(errKey) : error));
      setIsError(true);
      setGoogleLoading(false);
    }
  }

  const isSignup = mode === 'signup';

  return (
    <div className="min-h-screen flex">
      {/* Hero panel */}
      <div className="hidden lg:flex lg:w-[55%] xl:w-[58%] bg-gradient-to-br from-teal-950 via-teal-900 to-teal-800 text-teal-50 p-12 xl:p-16 flex-col justify-between relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-teal-700/20 rounded-full blur-3xl -mr-32 -mt-32" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl -ml-20 -mb-20" />

        <div className="relative flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-teal-400 to-cyan-400 grid place-items-center shadow-lg shadow-teal-900/50">
              <Heart className="w-6 h-6 text-teal-950" fill="currentColor" />
            </div>
            <span className="text-xl font-bold tracking-tight">{t('app_name')}</span>
          </div>
          {/* Language switcher */}
          <div className="flex items-center gap-1.5 bg-teal-900/50 rounded-xl p-1">
            {LANGS.map(l => (
              <button
                key={l.code}
                type="button"
                onClick={() => setLang(l.code as Lang)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                  lang === l.code ? 'bg-teal-600 text-white' : 'text-teal-300 hover:text-white'
                }`}
              >
                {l.native}
              </button>
            ))}
          </div>
        </div>

        <div className="relative space-y-8">
          <h1 className="text-4xl xl:text-5xl font-bold leading-[1.12] tracking-tight max-w-[20ch]">
            {t('hero_title')}
          </h1>
          <ul className="space-y-4 text-teal-100/90 text-lg">
            <li className="flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 mt-1 text-teal-300 flex-none" />
              <span>{t('hero_feat1')}</span>
            </li>
            <li className="flex items-start gap-3">
              <Activity className="w-5 h-5 mt-1 text-teal-300 flex-none" />
              <span>{t('hero_feat2')}</span>
            </li>
            <li className="flex items-start gap-3">
              <Droplet className="w-5 h-5 mt-1 text-teal-300 flex-none" />
              <span>{t('hero_feat3')}</span>
            </li>
          </ul>
        </div>

        <p className="relative text-teal-300/70 text-sm">{t('disclaimer')}</p>
      </div>

      {/* Form panel */}
      <div className="flex-1 flex items-center justify-center p-6 sm:p-10 bg-gray-50 relative">
        {/* Mobile language switcher */}
        <div className="lg:hidden absolute top-4 right-4 flex items-center gap-1 bg-white rounded-xl p-1 shadow-sm border border-gray-200">
          {LANGS.map(l => (
            <button
              key={l.code}
              type="button"
              onClick={() => setLang(l.code as Lang)}
              className={`px-2 py-1 rounded-lg text-xs font-semibold transition-all ${
                lang === l.code ? 'bg-teal-600 text-white' : 'text-gray-500'
              }`}
            >
              {l.native}
            </button>
          ))}
        </div>

        <div className="w-full max-w-md">
          {/* Mobile brand */}
          <div className="lg:hidden flex items-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-cyan-500 grid place-items-center">
              <Heart className="w-5 h-5 text-white" fill="currentColor" />
            </div>
            <span className="text-lg font-bold text-teal-950">{t('app_name')}</span>
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-1">
            {isSignup ? t('create_account') : t('welcome_back')}
          </h2>
          <p className="text-gray-500 text-sm mb-8">
            {isSignup ? t('signup_subtitle') : t('signin_subtitle')}
          </p>

          {/* Toggle */}
          <div className="flex bg-gray-100 rounded-xl p-1 mb-6">
            <button
              type="button"
              onClick={() => { setMode('signin'); setMsg(''); }}
              className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                !isSignup ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              {t('signin')}
            </button>
            <button
              type="button"
              onClick={() => { setMode('signup'); setMsg(''); }}
              className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${
                isSignup ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              {t('signup')}
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignup && (
              <div>
                <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('full_name')}</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    value={fullName}
                    onChange={e => setFullName(e.target.value)}
                    autoComplete="name"
                    placeholder={t('full_name_ph')}
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('email')}</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  autoComplete="email"
                  required
                  placeholder={t('email_ph')}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('password')}</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type={showPw ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  autoComplete={isSignup ? 'new-password' : 'current-password'}
                  minLength={8}
                  required
                  placeholder={t('password_ph')}
                  className="w-full pl-10 pr-11 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                >
                  {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {msg && (
              <p className={`text-sm ${isError ? 'text-rose-600' : 'text-teal-600'} font-medium`}>{msg}</p>
            )}

            <button
              type="submit"
              disabled={busy}
              className="w-full py-3 rounded-xl bg-teal-700 text-white font-semibold text-sm hover:bg-teal-800 active:scale-[.98] transition-all disabled:opacity-60 disabled:cursor-default shadow-lg shadow-teal-700/20"
            >
              {busy ? (isSignup ? t('creating') : t('signing_in')) : (isSignup ? t('signup') : t('signin'))}
            </button>
          </form>

          <div className="flex items-center gap-3 my-6">
            <div className="flex-1 h-px bg-gray-200" />
            <span className="text-xs text-gray-400 font-medium">{t('or')}</span>
            <div className="flex-1 h-px bg-gray-200" />
          </div>

          <button
            type="button"
            onClick={handleGoogle}
            disabled={googleLoading}
            className="w-full py-3 rounded-xl bg-white border border-gray-300 text-gray-700 font-semibold text-sm hover:bg-gray-50 active:scale-[.98] transition-all flex items-center justify-center gap-3 disabled:opacity-60 disabled:cursor-default"
          >
            {googleLoading ? (
              <svg className="animate-spin" width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" opacity="0.25"/>
                <path d="M22 12a10 10 0 0 1-10 10" stroke="currentColor" strokeWidth="3" strokeLinecap="round"/>
              </svg>
            ) : (
              <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
                <path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9 3.5l6.7-6.7C35.6 2.4 30.2 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.8 6C12.3 13.5 17.7 9.5 24 9.5z"/>
                <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4 7-10 7-17.5z"/>
                <path fill="#FBBC05" d="M10.4 28.8c-.5-1.5-.8-3-.8-4.8s.3-3.3.8-4.8l-7.8-6C.9 16.5 0 20.1 0 24s.9 7.5 2.6 10.8l7.8-6z"/>
                <path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.5-5.8c-2.1 1.4-4.8 2.3-8.4 2.3-6.3 0-11.7-4.3-13.6-10l-7.8 6C6.5 42.6 14.6 48 24 48z"/>
              </svg>
            )}
            {googleLoading ? t('redirecting_google') : t('continue_google')}
          </button>

          <p className="text-center text-xs text-gray-400 mt-8">{t('auth_note')}</p>
        </div>
      </div>
    </div>
  );
}
