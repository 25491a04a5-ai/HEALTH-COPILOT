import { useState } from 'react';
import { Stethoscope, AlertTriangle, Sparkles, ArrowRight, X, Circle, HeartPulse, Activity, Brain, Eye, Ear, Hand, Droplet, Bone, Zap } from 'lucide-react';
import { SYMPTOMS, EMERGENCY_SYMPTOMS, SPECIALTY_MAP, SpecialtyKey, BODY_AREAS, BodyArea } from '@/lib/constants';
import { Hospital } from '@/lib/types';
import { useLang } from '@/context/LangContext';

interface Suggestion {
  specialty: string;
  isBest: boolean;
  reasons: string[];
}

interface Props {
  hospitals: Hospital[];
  onFindHospitals: (specialty: string) => void;
}

const AREA_ICONS: Record<BodyArea, typeof Circle> = {
  head: Brain,
  chest: HeartPulse,
  abdomen: Activity,
  limbs: Hand,
  skin: Droplet,
};

const SEVERITY_COLORS = ['bg-emerald-500', 'bg-amber-500', 'bg-rose-500'];
const DURATION_KEYS = ['duration_hours', 'duration_days', 'duration_week'] as const;
const SEVERITY_KEYS = ['severity_mild', 'severity_moderate', 'severity_severe'] as const;

export default function SymptomsView({ hospitals, onFindHospitals }: Props) {
  const { t } = useLang();
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [activeArea, setActiveArea] = useState<BodyArea>('head');
  const [severity, setSeverity] = useState(1);
  const [duration, setDuration] = useState(0);
  const [suggestions, setSuggestions] = useState<Suggestion[] | null>(null);
  const [showEmergency, setShowEmergency] = useState(false);

  function toggleSymptom(id: string) {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id); else next.add(id);
    setSelected(next);
  }

  function clearAll() {
    setSelected(new Set());
    setSuggestions(null);
    setShowEmergency(false);
    setSeverity(1);
    setDuration(0);
  }

  function recommend() {
    if (selected.size === 0) {
      clearAll();
      return;
    }

    const selArr = [...selected];

    if (selArr.some(s => EMERGENCY_SYMPTOMS.includes(s))) {
      setShowEmergency(true);
      setSuggestions(null);
      return;
    }

    setShowEmergency(false);
    const score: Record<string, number> = {};
    const why: Record<string, string[]> = {};

    for (const id of selArr) {
      const symptom = SYMPTOMS.find(s => s.id === id);
      if (!symptom) continue;
      for (const [key, weight] of Object.entries(symptom.weights)) {
        const sevMultiplier = severity === 0 ? 0.7 : severity === 1 ? 1 : 1.4;
        score[key] = (score[key] ?? 0) + weight * sevMultiplier;
        if (!why[key]) why[key] = [];
        why[key].push(t(symptom.labelKey));
      }
    }

    const sorted = Object.entries(score).sort((a, b) => b[1] - a[1]).slice(0, 2);
    if (sorted.length === 0) sorted.push(['gen', 1]);

    const result: Suggestion[] = sorted.map(([key], i) => ({
      specialty: t(`spec_${key}`) || SPECIALTY_MAP[key as SpecialtyKey] || t('general_medicine'),
      isBest: i === 0,
      reasons: why[key] ?? [t('general_symptoms')],
    }));

    setSuggestions(result);
  }

  function getUrgencyLevel(): { label: string; color: string; bg: string } {
    if (severity === 2 && duration <= 1) return { label: t('urgency_high'), color: 'text-rose-700', bg: 'bg-rose-50 border-rose-200' };
    if (severity === 2 || (severity === 1 && duration <= 1)) return { label: t('urgency_medium'), color: 'text-amber-700', bg: 'bg-amber-50 border-amber-200' };
    return { label: t('urgency_low'), color: 'text-emerald-700', bg: 'bg-emerald-50 border-emerald-200' };
  }

  function getAdvice(): string {
    if (severity === 2) return t('see_specialist_urgent');
    if (severity === 1 && duration >= 1) return t('see_specialist');
    return t('rest_advice');
  }

  function hasHospitalsFor(specialty: string): boolean {
    return hospitals.some(h => h.specialty === specialty);
  }

  const areaSymptoms = SYMPTOMS.filter(s => s.bodyArea === activeArea);
  const urgency = suggestions ? getUrgencyLevel() : null;
  const tipKeys = ['tip_rest', 'tip_monitor', 'tip_avoid'];

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Left: Body area selector + symptoms */}
        <div className="bg-white rounded-2xl border border-gray-200 p-6 animate-rise">
          <div className="flex items-center gap-2.5 mb-1">
            <Stethoscope className="w-5 h-5 text-teal-600" />
            <h2 className="text-lg font-bold text-gray-900">{t('what_feeling')}</h2>
          </div>
          <p className="text-sm text-gray-500 mb-5">{t('symptom_help')}</p>

          {/* Body area selector */}
          <div className="grid grid-cols-5 gap-2 mb-5">
            {BODY_AREAS.map(area => {
              const Icon = AREA_ICONS[area.key];
              const isActive = activeArea === area.key;
              const count = SYMPTOMS.filter(s => s.bodyArea === area.key && selected.has(s.id)).length;
              return (
                <button
                  key={area.key}
                  type="button"
                  onClick={() => setActiveArea(area.key)}
                  className={`relative flex flex-col items-center gap-1.5 py-3 rounded-xl border transition-all ${
                    isActive
                      ? 'bg-teal-50 border-teal-400 shadow-sm'
                      : 'bg-gray-50 border-gray-200 hover:border-teal-300'
                  }`}
                >
                  <Icon className={`w-5 h-5 ${isActive ? 'text-teal-600' : 'text-gray-400'}`} />
                  <span className={`text-[10px] font-semibold text-center leading-tight ${isActive ? 'text-teal-700' : 'text-gray-500'}`}>
                    {t(area.labelKey)}
                  </span>
                  {count > 0 && (
                    <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-teal-600 text-white text-[10px] font-bold grid place-items-center">
                      {count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Symptoms for active area */}
          <div className="min-h-[80px] mb-5">
            {areaSymptoms.length === 0 ? (
              <p className="text-sm text-gray-400 text-center py-4">{t('no_symptoms_body')}</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {areaSymptoms.map(s => {
                  const isEmergency = EMERGENCY_SYMPTOMS.includes(s.id);
                  const isSelected = selected.has(s.id);
                  return (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => toggleSymptom(s.id)}
                      className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all border ${
                        isSelected
                          ? isEmergency
                            ? 'bg-rose-600 text-white border-rose-600 shadow-sm'
                            : 'bg-teal-700 text-white border-teal-700 shadow-sm'
                          : isEmergency
                            ? 'bg-white text-rose-600 border-rose-200 hover:border-rose-400'
                            : 'bg-white text-gray-700 border-gray-300 hover:border-teal-400'
                      }`}
                    >
                      {t(s.labelKey)}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Severity slider */}
          <div className="mb-5">
            <label className="block text-sm font-semibold text-gray-600 mb-2">{t('severity')}</label>
            <div className="flex gap-2">
              {SEVERITY_KEYS.map((sevKey, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setSeverity(i)}
                  className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all border-2 ${
                    severity === i
                      ? `${SEVERITY_COLORS[i]} text-white border-transparent shadow-md`
                      : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300'
                  }`}
                >
                  {t(sevKey)}
                </button>
              ))}
            </div>
          </div>

          {/* Duration selector */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-600 mb-2">{t('duration')}</label>
            <div className="flex gap-2">
              {DURATION_KEYS.map((durKey, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setDuration(i)}
                  className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all border ${
                    duration === i
                      ? 'bg-gray-900 text-white border-gray-900'
                      : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300'
                  }`}
                >
                  {t(durKey)}
                </button>
              ))}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex gap-3 items-center">
            <button
              type="button"
              onClick={recommend}
              className="px-5 py-2.5 rounded-xl bg-teal-700 text-white font-semibold text-sm hover:bg-teal-800 active:scale-[.98] transition-all shadow-lg shadow-teal-700/20 flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              {t('get_suggestion')}
            </button>
            <button
              type="button"
              onClick={clearAll}
              className="px-4 py-2.5 rounded-xl border border-gray-300 text-teal-700 font-semibold text-sm hover:bg-gray-50 transition-all flex items-center gap-2"
            >
              <X className="w-4 h-4" />
              {t('clear')}
            </button>
            {selected.size > 0 && (
              <span className="text-sm text-gray-400 font-medium ml-auto">
                {selected.size} {t('selected_count')}
              </span>
            )}
          </div>
        </div>

        {/* Right: Suggestion panel */}
        <div className="bg-white rounded-2xl border border-gray-200 p-6 animate-rise [animation-delay:80ms]">
          <h2 className="text-lg font-bold text-gray-900 mb-4">{t('suggestion')}</h2>

          {showEmergency ? (
            <div>
              <div className="bg-rose-50 border border-rose-200 rounded-xl p-4 mb-4 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-rose-600 flex-none mt-0.5 animate-pulse" />
                <div>
                  <p className="font-bold text-rose-700">{t('emergency_detected')}</p>
                  <p className="text-sm text-rose-600 mt-1">{t('emergency_call')}</p>
                </div>
              </div>
              <p className="text-sm text-gray-500 mb-4">{t('emergency_note')}</p>
              <button
                type="button"
                onClick={() => onFindHospitals('')}
                className="px-5 py-2.5 rounded-xl bg-teal-700 text-white font-semibold text-sm hover:bg-teal-800 transition-all"
              >
                {t('show_hospitals')}
              </button>
            </div>
          ) : suggestions ? (
            <div className="space-y-4">
              {/* Urgency banner */}
              {urgency && (
                <div className={`rounded-xl border p-3.5 ${urgency.bg}`}>
                  <div className="flex items-center gap-2.5">
                    <Zap className={`w-5 h-5 ${urgency.color}`} />
                    <div>
                      <p className={`font-bold text-sm ${urgency.color}`}>{urgency.label}</p>
                      <p className="text-xs text-gray-600 mt-0.5">{getAdvice()}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Specialist suggestions */}
              {suggestions.map((s, i) => (
                <div
                  key={i}
                  className="flex items-start justify-between gap-3 border border-gray-200 rounded-xl p-4"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-bold text-gray-900">{s.specialty}</span>
                      {s.isBest && (
                        <span className="text-xs font-semibold bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">
                          {t('best_match')}
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-400">
                      {t('because')} {s.reasons.join(', ')}
                    </p>
                  </div>
                  {hasHospitalsFor(s.specialty) && (
                    <button
                      type="button"
                      onClick={() => onFindHospitals(s.specialty)}
                      className="px-3 py-2 rounded-lg border border-gray-300 text-teal-700 font-semibold text-sm hover:bg-gray-50 transition-all flex items-center gap-1.5 flex-none whitespace-nowrap"
                    >
                      {t('find_hospitals')}
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}

              {/* Self-care tips */}
              <div className="bg-gray-50 rounded-xl p-4">
                <p className="text-sm font-bold text-gray-700 mb-2">{t('self_care_tips')}</p>
                <ul className="space-y-1.5">
                  {tipKeys.map(key => (
                    <li key={key} className="text-sm text-gray-500 flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-teal-400 mt-1.5 flex-none" />
                      {t(key)}
                    </li>
                  ))}
                </ul>
              </div>

              <p className="text-xs text-gray-400">{t('not_diagnosis')}</p>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-teal-50 to-cyan-50 grid place-items-center mb-4 border border-teal-100">
                <Stethoscope className="w-8 h-8 text-teal-300" />
              </div>
              <p className="text-sm text-gray-400 mb-1">{t('choose_symptoms')}</p>
              <p className="text-xs text-gray-300">{selected.size} {t('symptoms_count')} {t('selected_count')}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
