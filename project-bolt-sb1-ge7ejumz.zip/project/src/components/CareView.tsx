import { useState, useEffect, useCallback } from 'react';
import {
  Building2, Phone, Droplet, MapPin, X, Stethoscope, ChevronDown, Hospital as HospitalIcon,
  Heart, BedDouble, Sparkles, Activity,
  Navigation, Siren, Users, Ambulance, Pill, TestTube, Scissors, Syringe,
  Baby, Brain, Eye, Ear, Bone, Zap, Clock,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Hospital, HospitalDepartment } from '@/lib/types';
import {
  CITIES, INDIA_STATES, telLink,
  translateSpecialty, translateHospitalType, HOSPITAL_TYPE_LABEL_KEY,
} from '@/lib/constants';

const SERVICE_ICONS: Record<string, typeof Activity> = {
  'ICU': Heart,
  'Ambulance': Ambulance,
  'Pharmacy': Pill,
  'Diagnostics': TestTube,
  '24/7 Emergency': Siren,
  'OPD': Stethoscope,
  'Maternity': Baby,
  'Maternity Ward': Baby,
  'Surgery': Scissors,
  'Blood Bank': Droplet,
  'Cafeteria': Users,
  'Eye Surgery': Eye,
  'ENT Surgery': Ear,
  'Charitable Ward': Heart,
  'Free OPD': Stethoscope,
  'Free OPD Tuesday': Stethoscope,
  'Neonatal Care': Baby,
};

function ServiceIcon({ name }: { name: string }) {
  const Icon = SERVICE_ICONS[name] ?? Sparkles;
  return <Icon className="w-3.5 h-3.5" />;
}
import { useLang } from '@/context/LangContext';
import { useToast } from './Toast';

export default function CareView({ initialSpecialty }: { initialSpecialty: string }) {
  const { t } = useLang();
  const toast = useToast();

  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [selectedState, setSelectedState] = useState<string>('Andhra Pradesh');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('');
  const [selectedCity, setSelectedCity] = useState<string>('Ongole');
  const [specialtyFilter, setSpecialtyFilter] = useState<string>(initialSpecialty);
  const [selectedHospital, setSelectedHospital] = useState<Hospital | null>(null);

  const districts = INDIA_STATES.find(s => s.name === selectedState)?.districts ?? [];
  const cities = districts.find(d => d.name === selectedDistrict)?.cities ?? CITIES;

  useEffect(() => {
    if (initialSpecialty) setSpecialtyFilter(initialSpecialty);
  }, [initialSpecialty]);

  useEffect(() => {
    if (districts.length > 0 && !selectedDistrict) {
      setSelectedDistrict(districts[0].name);
      setSelectedCity(districts[0].cities[0] ?? CITIES[0]);
    }
  }, [selectedState]);

  useEffect(() => {
    if (selectedDistrict) {
      const dcities = districts.find(d => d.name === selectedDistrict)?.cities ?? [];
      if (dcities.length > 0 && !dcities.includes(selectedCity)) {
        setSelectedCity(dcities[0]);
      }
    }
  }, [selectedDistrict]);

  const loadHospitals = useCallback(async () => {
    const { data, error } = await supabase.from('hospitals').select('*').order('name');
    if (error) return toast(t('hospitals') + ': ' + error.message, 'err');
    setHospitals(data as Hospital[]);
  }, [toast, t]);

  useEffect(() => {
    loadHospitals();
  }, [loadHospitals]);

  const specialties = [t('all_specialties'), ...new Set(hospitals.map(h => translateSpecialty(h.specialty, t)).sort())];

  const filteredHospitals = hospitals.filter(h => {
    const translatedSpec = translateSpecialty(h.specialty, t);
    const matchesSpecialty = !specialtyFilter || specialtyFilter === t('all_specialties') || translatedSpec === specialtyFilter || h.specialty === specialtyFilter;
    const matchesZone = h.zone === selectedCity || h.district === selectedDistrict;
    return matchesSpecialty && matchesZone;
  });

  const typeColors: Record<string, string> = {
    'Government': 'bg-teal-100 text-teal-700',
    'Private': 'bg-sky-100 text-sky-700',
    'Super Speciality': 'bg-violet-100 text-violet-700',
    'Cancer': 'bg-rose-100 text-rose-700',
  };

  return (
    <div className="space-y-5">
      {/* Location dropdown bar */}
      <div className="bg-white rounded-2xl border border-gray-200 p-4 animate-rise">
        <div className="flex items-center gap-3 mb-3">
          <MapPin className="w-5 h-5 text-teal-600" />
          <h3 className="text-sm font-bold text-gray-900">{t('select_location')}</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="relative">
            <select
              value={selectedState}
              onChange={e => { setSelectedState(e.target.value); setSelectedDistrict(''); }}
              className="w-full appearance-none px-4 py-2.5 rounded-xl border border-gray-300 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all bg-white pr-10"
            >
              {INDIA_STATES.map(s => <option key={s.name} value={s.name}>{s.name}</option>)}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
          </div>
          <div className="relative">
            <select
              value={selectedDistrict}
              onChange={e => setSelectedDistrict(e.target.value)}
              className="w-full appearance-none px-4 py-2.5 rounded-xl border border-gray-300 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all bg-white pr-10"
            >
              <option value="">{t('select_district')}</option>
              {districts.map(d => <option key={d.name} value={d.name}>{d.name}</option>)}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
          </div>
          <div className="relative">
            <select
              value={selectedCity}
              onChange={e => setSelectedCity(e.target.value)}
              className="w-full appearance-none px-4 py-2.5 rounded-xl border border-gray-300 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all bg-white pr-10"
            >
              {(cities.length > 0 ? cities : CITIES).map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Hospitals panel */}
        <div className="bg-white rounded-2xl border border-gray-200 p-6 animate-rise">
          <div className="flex items-center gap-2.5 mb-1">
            <Building2 className="w-5 h-5 text-teal-600" />
            <h2 className="text-lg font-bold text-gray-900">{t('hospitals')}</h2>
          </div>
          <p className="text-sm text-gray-500 mb-5">{t('hospitals_sub')}</p>

          <div className="mb-4">
            <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('specialty')}</label>
            <select
              value={specialtyFilter || t('all_specialties')}
              onChange={e => setSpecialtyFilter(e.target.value === t('all_specialties') ? '' : e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all bg-white"
            >
              {specialties.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>

          {filteredHospitals.length === 0 ? (
            <div className="text-center py-10 border-2 border-dashed border-gray-200 rounded-xl text-gray-400 text-sm">
              {t('no_hospital_specialty')}
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
              {filteredHospitals.map((h) => (
                <div
                  key={h.id}
                  onClick={() => setSelectedHospital(h)}
                  className="flex items-start justify-between gap-3 border border-gray-200 rounded-xl p-3.5 hover:border-teal-300 hover:shadow-md hover:shadow-teal-100 transition-all cursor-pointer group"
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm group-hover:text-teal-700 transition-colors">{h.name}</p>
                    <p className="text-sm text-teal-600 font-medium">{translateSpecialty(h.specialty, t)}</p>
                    {h.address && (
                      <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
                        <MapPin className="w-3 h-3" />{h.address}
                      </p>
                    )}
                    <div className="flex items-center gap-2 mt-2 flex-wrap">
                      {h.hospital_type && (
                        <span className={`inline-block text-xs font-semibold px-2.5 py-0.5 rounded-full ${typeColors[h.hospital_type] ?? 'bg-gray-100 text-gray-600'}`}>
                          {translateHospitalType(h.hospital_type, t)}
                        </span>
                      )}
                      <span className={`inline-block text-xs font-semibold px-2.5 py-0.5 rounded-full ${
                        h.has_emergency ? 'bg-emerald-100 text-emerald-700' : 'bg-sky-100 text-sky-700'
                      }`}>
                        {h.has_emergency ? t('emergency_24h') : t('no_emergency')}
                      </span>
                      {h.departments && h.departments.length > 0 && (
                        <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-violet-100 text-violet-700">
                          {h.departments.length} {t('departments')}
                        </span>
                      )}
                    </div>
                  </div>
                  {h.phone && (
                    <a
                      href={`tel:${telLink(h.phone)}`}
                      onClick={e => e.stopPropagation()}
                      className="flex items-center gap-1.5 text-teal-700 font-bold text-sm whitespace-nowrap hover:underline flex-none"
                    >
                      <Phone className="w-4 h-4" />
                      {t('call')}
                    </a>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

      {/* Hospital detail modal */}
      {selectedHospital && (
        <HospitalModal
          hospital={selectedHospital}
          onClose={() => setSelectedHospital(null)}
          t={t}
        />
      )}
    </div>
  );
}

// ─── Hospital detail popup with attractive animations ───
function HospitalModal({
  hospital, onClose, t,
}: {
  hospital: Hospital;
  onClose: () => void;
  t: (k: string) => string;
}) {
  const depts: HospitalDepartment[] = hospital.departments ?? [];
  const services: string[] = hospital.services ?? [];
  const isGovt = hospital.hospital_type === 'Government';
  const isCharitable = hospital.services?.some(s => s.includes('Charitable') || s.includes('Free')) ?? false;
  const maxBeds = 1000;
  const bedPct = hospital.beds ? Math.min(100, (hospital.beds / maxBeds) * 100) : 0;

  const typeColors: Record<string, string> = {
    'Government': 'bg-teal-100 text-teal-700',
    'Private': 'bg-sky-100 text-sky-700',
    'Super Speciality': 'bg-violet-100 text-violet-700',
    'Cancer': 'bg-rose-100 text-rose-700',
  };

  const typeGradients: Record<string, string> = {
    'Government': 'from-teal-600 via-cyan-600 to-teal-700',
    'Private': 'from-sky-600 via-blue-600 to-sky-700',
    'Super Speciality': 'from-violet-600 via-purple-600 to-violet-700',
    'Cancer': 'from-rose-600 via-pink-600 to-rose-700',
  };

  const gradient = typeGradients[hospital.hospital_type ?? ''] ?? 'from-teal-700 via-cyan-700 to-teal-800';

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-black/50 backdrop-blur-sm p-4 animate-backdrop"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl shadow-2xl max-w-lg w-full max-h-[88vh] overflow-y-auto animate-modal-pop"
        onClick={e => e.stopPropagation()}
      >
        {/* Header with gradient — color matches hospital type */}
        <div className={`sticky top-0 bg-gradient-to-br ${gradient} p-6 flex items-start justify-between gap-3 rounded-t-3xl relative overflow-hidden`}>
          <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full blur-2xl -mr-16 -mt-16" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full blur-xl -ml-12 -mb-12" />
          <div className="flex items-start gap-3 text-white relative">
            <div className="w-12 h-12 rounded-2xl bg-white/20 grid place-items-center flex-none backdrop-blur-sm">
              <HospitalIcon className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <h3 className="text-lg font-bold leading-tight">{hospital.name}</h3>
              <p className="text-sm text-white/80 mt-0.5">{translateSpecialty(hospital.specialty, t)}</p>
              {(isGovt || isCharitable) && (
                <span className="inline-flex items-center gap-1 mt-2 text-xs font-semibold px-2.5 py-1 rounded-full bg-white/20 backdrop-blur-sm">
                  <Heart className="w-3 h-3" fill="currentColor" />
                  {isCharitable ? t('free_care') : t('affordable_care')}
                </span>
              )}
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl text-white/80 hover:text-white hover:bg-white/15 transition-all flex-none relative"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          {/* Interactive stat cards */}
          <div className="grid grid-cols-3 gap-3 animate-dept" style={{ animationDelay: '0.05s' }}>
            {/* Beds card */}
            {hospital.beds != null && (
              <div className="rounded-xl border border-gray-200 p-3 text-center hover:border-teal-300 hover:shadow-md hover:shadow-teal-50 transition-all group cursor-default">
                <div className="w-9 h-9 rounded-lg bg-teal-50 grid place-items-center mx-auto mb-1.5 group-hover:scale-110 transition-transform">
                  <BedDouble className="w-4.5 h-4.5 text-teal-600" />
                </div>
                <p className="text-xl font-bold text-gray-900 leading-none">{hospital.beds}</p>
                <p className="text-[10px] text-gray-400 font-medium mt-1">{t('bed_capacity')}</p>
              </div>
            )}
            {/* Departments card */}
            <div className="rounded-xl border border-gray-200 p-3 text-center hover:border-teal-300 hover:shadow-md hover:shadow-teal-50 transition-all group cursor-default">
              <div className="w-9 h-9 rounded-lg bg-violet-50 grid place-items-center mx-auto mb-1.5 group-hover:scale-110 transition-transform">
                <Stethoscope className="w-4.5 h-4.5 text-violet-600" />
              </div>
              <p className="text-xl font-bold text-gray-900 leading-none">{depts.length}</p>
              <p className="text-[10px] text-gray-400 font-medium mt-1">{t('specialist_count')}</p>
            </div>
            {/* Emergency card */}
            <div className={`rounded-xl border p-3 text-center transition-all group cursor-default ${hospital.has_emergency ? 'border-emerald-200 hover:border-emerald-400 hover:shadow-md hover:shadow-emerald-50' : 'border-gray-200'}`}>
              <div className={`w-9 h-9 rounded-lg grid place-items-center mx-auto mb-1.5 group-hover:scale-110 transition-transform ${hospital.has_emergency ? 'bg-emerald-50' : 'bg-gray-50'}`}>
                {hospital.has_emergency ? <Siren className="w-4.5 h-4.5 text-emerald-600" /> : <Clock className="w-4.5 h-4.5 text-gray-400" />}
              </div>
              <p className="text-xs font-bold text-gray-900 leading-none">{hospital.has_emergency ? t('emergency_24h') : t('no_emergency')}</p>
            </div>
          </div>

          {/* Bed capacity bar */}
          {hospital.beds != null && (
            <div className="animate-dept" style={{ animationDelay: '0.1s' }}>
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="font-semibold text-gray-500">{t('bed_capacity')}</span>
                <span className="font-bold text-teal-700">{hospital.beds}</span>
              </div>
              <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-teal-400 to-cyan-500 rounded-full transition-all"
                  style={{ width: `${bedPct}%` }}
                />
              </div>
            </div>
          )}

          {/* Info badges with stagger */}
          <div className="flex flex-wrap gap-2 animate-dept" style={{ animationDelay: '0.12s' }}>
            {hospital.hospital_type && (
              <span className={`text-xs font-semibold px-3 py-1 rounded-full ${typeColors[hospital.hospital_type] ?? 'bg-gray-100 text-gray-600'}`}>
                {translateHospitalType(hospital.hospital_type, t)}
              </span>
            )}
            {isCharitable && (
              <span className="text-xs font-semibold px-3 py-1 rounded-full bg-emerald-100 text-emerald-700">
                {t('free_care')}
              </span>
            )}
            {isGovt && (
              <span className="text-xs font-semibold px-3 py-1 rounded-full bg-teal-100 text-teal-700">
                {t('govt_benefits')}
              </span>
            )}
            {hospital.district && (
              <span className="text-xs font-semibold px-3 py-1 rounded-full bg-gray-100 text-gray-600">
                {hospital.district}
              </span>
            )}
          </div>

          {/* Contact & Location section */}
          <div className="space-y-2.5 animate-dept" style={{ animationDelay: '0.18s' }}>
            <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wide">{t('contact_info')}</h4>
            {hospital.address && (
              <div className="flex items-start gap-2.5 text-sm text-gray-600">
                <MapPin className="w-4 h-4 text-teal-500 flex-none mt-0.5" />
                <p>{hospital.address}</p>
              </div>
            )}
            <div className="flex items-center gap-2">
              {hospital.phone && (
                <a
                  href={`tel:${telLink(hospital.phone)}`}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-700 text-white font-bold text-sm hover:bg-teal-800 active:scale-[.98] transition-all flex-1 justify-center shadow-lg shadow-teal-700/20"
                >
                  <Phone className="w-4 h-4" />
                  {t('call')} {hospital.phone}
                </a>
              )}
              {hospital.address && (
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(hospital.name + ' ' + hospital.address)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-teal-200 text-teal-700 font-bold text-sm hover:bg-teal-50 active:scale-[.98] transition-all flex-1 justify-center"
                >
                  <Navigation className="w-4 h-4" />
                  {t('get_directions')}
                </a>
              )}
            </div>
          </div>

          {/* Services with icons */}
          {services.length > 0 && (
            <div className="animate-dept" style={{ animationDelay: '0.25s' }}>
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-4 h-4 text-teal-600" />
                <h4 className="text-sm font-bold text-gray-900">{t('available_services')}</h4>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {services.map((s, i) => (
                  <div key={i} className="flex items-center gap-2 px-2.5 py-2 rounded-lg bg-teal-50/60 border border-teal-100 hover:bg-teal-50 hover:border-teal-200 transition-all">
                    <span className="text-teal-600 flex-none"><ServiceIcon name={s} /></span>
                    <span className="text-xs font-medium text-teal-800 truncate">{s}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Departments with specialist names — staggered slide-in */}
          {depts.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Stethoscope className="w-4 h-4 text-teal-600" />
                <h4 className="text-sm font-bold text-gray-900">{t('departments')}</h4>
              </div>
              <div className="space-y-2">
                {depts.map((d, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between gap-3 p-3 rounded-xl border border-gray-100 hover:border-teal-200 hover:bg-teal-50/20 transition-all animate-dept"
                    style={{ animationDelay: `${0.3 + i * 0.06}s` }}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-teal-50 grid place-items-center flex-none">
                        <Heart className="w-4 h-4 text-teal-600" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-gray-900 truncate">{d.name}</p>
                        <p className="text-xs text-teal-600 font-medium">{d.specialist}</p>
                      </div>
                    </div>
                    {d.phone && (
                      <a
                        href={`tel:${telLink(d.phone)}`}
                        className="flex items-center gap-1 text-xs font-bold text-teal-700 hover:underline flex-none"
                      >
                        <Phone className="w-3 h-3" />
                        {d.phone}
                      </a>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {depts.length === 0 && (
            <div className="text-center py-6 border-2 border-dashed border-gray-200 rounded-xl">
              <Stethoscope className="w-6 h-6 text-gray-200 mx-auto mb-1" />
              <p className="text-xs text-gray-400">{t('no_departments')}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
