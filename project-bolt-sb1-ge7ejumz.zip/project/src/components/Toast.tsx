import { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

type ToastKind = 'ok' | 'err' | 'info';

interface Toast {
  id: number;
  text: string;
  kind: ToastKind;
  exiting: boolean;
}

const ToastContext = createContext<{
  toast: (text: string, kind?: ToastKind) => void;
} | undefined>(undefined);

let toastId = 0;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const dismiss = useCallback((id: number) => {
    setToasts(prev => prev.map(t => t.id === id ? { ...t, exiting: true } : t));
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 300);
  }, []);

  const toast = useCallback((text: string, kind: ToastKind = 'ok') => {
    const id = ++toastId;
    setToasts(prev => [...prev, { id, text, kind, exiting: false }]);
    setTimeout(() => dismiss(id), 4200);
  }, [dismiss]);

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div className="fixed bottom-5 right-5 flex flex-col gap-2.5 z-[60] pointer-events-none">
        {toasts.map(t => {
          const config = {
            ok: { icon: CheckCircle2, accent: 'bg-emerald-500', bg: 'bg-white', text: 'text-gray-800', iconColor: 'text-emerald-500' },
            err: { icon: AlertCircle, accent: 'bg-rose-500', bg: 'bg-white', text: 'text-gray-800', iconColor: 'text-rose-500' },
            info: { icon: Info, accent: 'bg-sky-500', bg: 'bg-white', text: 'text-gray-800', iconColor: 'text-sky-500' },
          }[t.kind];
          const Icon = config.icon;

          return (
            <div
              key={t.id}
              className={`flex items-center gap-3 pl-0 pr-4 py-3 rounded-xl shadow-xl border border-gray-100 text-sm font-medium max-w-[360px] pointer-events-auto overflow-hidden ${config.bg} ${t.exiting ? 'animate-toast-out' : 'animate-toast-in'}`}
            >
              <div className={`w-1 h-full self-stretch rounded-l-xl ${config.accent}`} />
              <Icon className={`w-5 h-5 flex-none ${config.iconColor}`} />
              <span className={`flex-1 ${config.text}`}>{t.text}</span>
              <button
                type="button"
                onClick={() => dismiss(t.id)}
                className="p-0.5 rounded text-gray-300 hover:text-gray-600 transition-colors flex-none"
                aria-label="Dismiss"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx.toast;
}
