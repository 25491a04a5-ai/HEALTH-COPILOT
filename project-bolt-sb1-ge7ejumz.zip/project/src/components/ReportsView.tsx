import { useState, useEffect, useCallback, useRef, FormEvent } from 'react';
import {
  FileText, Search, Trash2, Plus, Calendar, Building2,
  Paperclip, Download, X, Upload, Eye, AlertCircle,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { PatientReport, REPORT_TYPES, ReportType } from '@/lib/types';
import { formatDate, REPORT_TYPE_LABEL_KEY } from '@/lib/constants';
import { useToast } from './Toast';
import { useAuth } from '@/context/AuthContext';
import { useLang } from '@/context/LangContext';
import ConfirmDialog from './ConfirmDialog';

const TYPE_STYLES: Record<string, string> = {
  Lab: 'bg-teal-50 text-teal-700 border-teal-200',
  Prescription: 'bg-blue-50 text-blue-700 border-blue-200',
  Scan: 'bg-sky-50 text-sky-700 border-sky-200',
  Discharge: 'bg-rose-50 text-rose-700 border-rose-200',
};

const ACCEPTED = 'application/pdf,image/jpeg,image/png,image/webp,image/gif';
const MAX_MB = 20;

export default function ReportsView() {
  const { user } = useAuth();
  const { t } = useLang();
  const toast = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [reports, setReports] = useState<PatientReport[]>([]);
  const [title, setTitle] = useState('');
  const [type, setType] = useState<ReportType>('Lab');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [hospital, setHospital] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<string>('All');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<PatientReport | null>(null);

  const loadReports = useCallback(async () => {
    if (!user) { setLoading(false); return; }
    const { data, error } = await supabase
      .from('patient_reports')
      .select('id, title, type, report_date, hospital, file_url, created_at, user_id')
      .order('report_date', { ascending: false });
    if (error) {
      toast(t('load_failed') + error.message, 'err');
      setLoading(false);
      return;
    }
    setReports((data ?? []) as PatientReport[]);
    setLoading(false);
  }, [user, toast, t]);

  useEffect(() => { loadReports(); }, [loadReports]);

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0] ?? null;
    setErrorMsg(null);
    if (!f) { setFile(null); return; }
    if (f.size > MAX_MB * 1024 * 1024) {
      setErrorMsg(t('file_too_large'));
      e.target.value = '';
      return;
    }
    setFile(f);
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    if (!user) {
      setErrorMsg(t('signin_first'));
      return;
    }
    setSaving(true);
    setErrorMsg(null);

    let file_url: string | null = null;

    // Refresh session to ensure auth token is current
    const { data: sessionData } = await supabase.auth.getSession();
    if (!sessionData.session) {
      setErrorMsg(t('signin_first'));
      setSaving(false);
      return;
    }

    const userId = sessionData.session.user.id;

    // Upload file if selected — but don't let file failure block the report save
    if (file) {
      const ext = file.name.split('.').pop();
      const safeExt = ext ? ext.replace(/[^a-zA-Z0-9]/g, '') : 'file';
      const path = `${userId}/${Date.now()}.${safeExt}`;
      const { error: upErr } = await supabase.storage
        .from('report-files')
        .upload(path, file, { contentType: file.type || 'application/octet-stream' });
      if (upErr) {
        toast(t('upload_failed') + upErr.message, 'err');
      } else {
        file_url = path;
      }
    }

    // Insert the report row — don't pass user_id, let DB DEFAULT auth.uid() handle it
    const { error } = await supabase.from('patient_reports').insert({
      title: title.trim(),
      type,
      report_date: date,
      hospital: hospital.trim() || null,
      file_url,
    });
    setSaving(false);
    if (error) {
      setErrorMsg(t('save_failed') + error.message);
      toast(t('save_failed') + error.message, 'err');
      return;
    }
    setTitle('');
    setHospital('');
    setFile(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    toast(t('report_saved'));
    loadReports();
  }

  async function handleDelete(report: PatientReport) {
    if (report.file_url) {
      await supabase.storage.from('report-files').remove([report.file_url]);
    }
    const { error } = await supabase.from('patient_reports').delete().eq('id', report.id);
    if (error) {
      toast(t('delete_failed') + error.message, 'err');
      return;
    }
    toast(t('report_deleted'));
    loadReports();
  }

  async function handleDownload(report: PatientReport) {
    if (!report.file_url) return;
    setDownloadingId(report.id);
    const { data, error } = await supabase.storage
      .from('report-files')
      .createSignedUrl(report.file_url, 60);
    setDownloadingId(null);
    if (error || !data?.signedUrl) {
      toast(t('download_failed'), 'err');
      return;
    }
    window.open(data.signedUrl, '_blank', 'noopener');
  }

  const filtered = reports.filter(r => {
    const matchesType = filterType === 'All' || r.type === filterType;
    const q = search.toLowerCase();
    return matchesType && `${r.title} ${r.type} ${r.hospital ?? ''}`.toLowerCase().includes(q);
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
      {/* Add report form */}
      <div className="bg-white rounded-2xl border border-gray-200 p-6 animate-rise">
        <div className="flex items-center gap-2.5 mb-4">
          <Plus className="w-5 h-5 text-teal-600" />
          <h2 className="text-lg font-bold text-gray-900">{t('add_report')}</h2>
        </div>

        {errorMsg && (
          <div className="mb-4 flex items-start gap-2 bg-rose-50 border border-rose-200 rounded-xl p-3 animate-rise">
            <AlertCircle className="w-4 h-4 text-rose-500 flex-none mt-0.5" />
            <p className="text-sm text-rose-700">{errorMsg}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('title')}</label>
            <input
              type="text"
              value={title}
              onChange={e => setTitle(e.target.value)}
              maxLength={200}
              required
              placeholder={t('title_ph')}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('type')}</label>
            <select
              value={type}
              onChange={e => setType(e.target.value as ReportType)}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all bg-white"
            >
              {REPORT_TYPES.map(rt => <option key={rt} value={rt}>{t(REPORT_TYPE_LABEL_KEY[rt] ?? rt)}</option>)}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('date')}</label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="date"
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  required
                  className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('hospital_clinic')}</label>
              <div className="relative">
                <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  value={hospital}
                  onChange={e => setHospital(e.target.value)}
                  placeholder={t('optional')}
                  className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all"
                />
              </div>
            </div>
          </div>

          {/* File upload */}
          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1.5">
              {t('attach_file')} <span className="font-normal text-gray-400">({t('optional')})</span>
            </label>
            <div
              className="relative border-2 border-dashed border-gray-200 rounded-xl p-4 hover:border-teal-400 transition-colors cursor-pointer group"
              onClick={() => fileInputRef.current?.click()}
            >
              {file ? (
                <div className="flex items-center gap-2.5">
                  <Paperclip className="w-5 h-5 text-teal-600 flex-none" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800 truncate">{file.name}</p>
                    <p className="text-xs text-gray-400">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>
                  <button
                    type="button"
                    onClick={ev => { ev.stopPropagation(); setFile(null); if (fileInputRef.current) fileInputRef.current.value = ''; }}
                    className="p-1 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-rose-500 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-1.5 py-2 text-center">
                  <Upload className="w-6 h-6 text-gray-300 group-hover:text-teal-500 transition-colors" />
                  <p className="text-sm text-gray-400 group-hover:text-teal-600 transition-colors">{t('drop_file')}</p>
                  <p className="text-xs text-gray-300">{t('upload_hint')} {MAX_MB} MB</p>
                </div>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept={ACCEPTED}
                onChange={handleFileChange}
                className="sr-only"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full py-3 rounded-xl bg-teal-700 text-white font-semibold text-sm hover:bg-teal-800 active:scale-[.98] transition-all disabled:opacity-60 disabled:cursor-default shadow-lg shadow-teal-700/20 flex items-center justify-center gap-2"
          >
            {saving ? (
              <>
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                {t('saving')}
              </>
            ) : (
              <>
                <Paperclip className="w-4 h-4" />
                {t('save_report')}
              </>
            )}
          </button>
        </form>
      </div>

      {/* Reports list */}
      <div className="bg-white rounded-2xl border border-gray-200 p-6 animate-rise [animation-delay:80ms]">
        <div className="flex items-center justify-between gap-3 mb-4 flex-wrap">
          <div className="flex items-center gap-2.5">
            <FileText className="w-5 h-5 text-teal-600" />
            <h2 className="text-lg font-bold text-gray-900">{t('your_reports')}</h2>
            {reports.length > 0 && (
              <span className="text-xs font-semibold bg-gray-100 text-gray-500 rounded-full px-2 py-0.5">
                {reports.length}
              </span>
            )}
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="search"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder={t('search')}
              className="pl-9 pr-4 py-2 rounded-lg border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent w-44 transition-all"
            />
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mb-4">
          {[t('all'), ...REPORT_TYPES.map(rt => t(REPORT_TYPE_LABEL_KEY[rt] ?? rt))].map(ft => (
            <button
              key={ft}
              type="button"
              onClick={() => setFilterType(ft === t('all') ? 'All' : REPORT_TYPES.find(rt => t(REPORT_TYPE_LABEL_KEY[rt] ?? rt) === ft) ?? ft)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all border ${
                (filterType === 'All' && ft === t('all')) || (REPORT_TYPES.find(rt => t(REPORT_TYPE_LABEL_KEY[rt] ?? rt) === ft) === filterType) || filterType === ft
                  ? 'bg-teal-700 text-white border-teal-700'
                  : 'bg-white text-gray-700 border-gray-300 hover:border-teal-400'
              }`}
            >
              {ft}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-16 bg-gray-100 rounded-xl animate-pulse" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-12 border-2 border-dashed border-gray-200 rounded-xl">
            <FileText className="w-8 h-8 text-gray-200 mx-auto mb-2" />
            <p className="text-sm text-gray-400">
              {reports.length === 0 ? t('no_reports') : t('no_match')}
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map(r => (
              <div
                key={r.id}
                className="flex items-start gap-3 p-3.5 rounded-xl border border-gray-100 hover:border-teal-200 hover:bg-teal-50/30 transition-all group"
              >
                <span className={`text-xs font-bold rounded-lg px-2 py-1 flex-none border mt-0.5 ${TYPE_STYLES[r.type] ?? 'bg-gray-100 text-gray-600 border-gray-200'}`}>
                  {t(REPORT_TYPE_LABEL_KEY[r.type] ?? r.type)}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-gray-900 truncate text-sm">{r.title}</p>
                  <p className="text-xs text-gray-400 truncate mt-0.5">
                    {[r.hospital, formatDate(r.report_date)].filter(Boolean).join(' · ')}
                  </p>
                  {r.file_url && (
                    <button
                      type="button"
                      onClick={() => handleDownload(r)}
                      disabled={downloadingId === r.id}
                      className="flex items-center gap-1 mt-1.5 text-xs text-teal-600 hover:text-teal-800 font-medium transition-colors disabled:opacity-50"
                    >
                      {downloadingId === r.id ? (
                        <span className="w-3 h-3 border border-teal-400 border-t-teal-700 rounded-full animate-spin" />
                      ) : (
                        <Eye className="w-3 h-3" />
                      )}
                      {t('view_file')}
                      <Download className="w-3 h-3" />
                    </button>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => setDeleteTarget(r)}
                  className="p-1.5 rounded-lg text-gray-300 hover:text-rose-600 hover:bg-rose-50 transition-all flex-none opacity-0 group-hover:opacity-100"
                  aria-label={t('delete_report')}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <ConfirmDialog
        open={deleteTarget !== null}
        title={t('delete_report')}
        message={t('delete_confirm')}
        confirmLabel={t('delete_report')}
        cancelLabel={t('clear')}
        onConfirm={() => {
          if (deleteTarget) handleDelete(deleteTarget);
          setDeleteTarget(null);
        }}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}
