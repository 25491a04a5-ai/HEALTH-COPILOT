import { useState, useEffect, useCallback } from 'react';
import {
  Droplet, Search, Phone, X, Plus, RefreshCw,
  AlertCircle, CheckCircle2, Clock, Shield, Upload, Edit2, Trash2,
  ChevronDown, Siren, Activity, ExternalLink, MapPin, Navigation,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import {
  BloodBank, BloodStock, BankWithStock, BloodRequest, BloodGroup, BLOOD_GROUPS,
} from '@/lib/types';
import { telLink, GOVT_BLOOD_PORTALS } from '@/lib/constants';
import { useAuth } from '@/context/AuthContext';
import { useLang } from '@/context/LangContext';
import { useToast } from './Toast';
import ConfirmDialog from './ConfirmDialog';

type Tab = 'finder' | 'request' | 'admin';

export default function BloodBankView() {
  const { user } = useAuth();
  const { t } = useLang();
  const [tab, setTab] = useState<Tab>('finder');
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase
      .from('blood_bank_admins')
      .select('id')
      .eq('user_id', user.id)
      .maybeSingle()
      .then(({ data }) => setIsAdmin(!!data));
  }, [user]);

  return (
    <div className="space-y-5">
      {/* Tab bar */}
      <div className="flex gap-2 bg-white rounded-2xl border border-gray-200 p-1.5 animate-rise">
        <TabButton active={tab === 'finder'} onClick={() => setTab('finder')} icon={Search} label={t('bb_finder')} />
        <TabButton active={tab === 'request'} onClick={() => setTab('request')} icon={Siren} label={t('bb_request')} />
        {isAdmin && (
          <TabButton active={tab === 'admin'} onClick={() => setTab('admin')} icon={Shield} label={t('bb_admin')} />
        )}
      </div>

      {tab === 'finder' && <FinderTab />}
      {tab === 'request' && <RequestTab />}
      {tab === 'admin' && isAdmin && <AdminTab />}
    </div>
  );
}

function TabButton({ active, onClick, icon: Icon, label }: {
  active: boolean; onClick: () => void; icon: typeof Search; label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all ${
        active ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/20' : 'text-gray-500 hover:bg-gray-50'
      }`}
    >
      <Icon className="w-4 h-4" />
      {label}
    </button>
  );
}

// ═══════════════════════════════════════════════════
// FINDER TAB — Official government blood bank portals
// ═══════════════════════════════════════════════════
function FinderTab() {
  const { t } = useLang();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [banks, setBanks] = useState<BankWithStock[]>([]);
  const [stockLoading, setStockLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [lastSync, setLastSync] = useState('');
  const [syncMessage, setSyncMessage] = useState('');

  const loadBanks = useCallback(async () => {
    const [banksRes, stockRes] = await Promise.all([
      supabase.from('blood_banks').select('*').order('name'),
      supabase.from('blood_stock').select('bank_id, blood_group, units, reported_at, verified, source'),
    ]);
    if (banksRes.error || stockRes.error) { setStockLoading(false); return; }

    const bankList = (banksRes.data as BloodBank[]).map(b => ({
      ...b,
      stock: Object.fromEntries(BLOOD_GROUPS.map(g => [g, 0])) as Record<string, number>,
      stockVerified: Object.fromEntries(BLOOD_GROUPS.map(g => [g, false])) as Record<string, boolean>,
      reported: false,
      lastUpdated: 0,
    }));

    for (const row of stockRes.data as BloodStock[]) {
      const b = bankList.find(x => x.id === row.bank_id);
      if (!b) continue;
      b.stock[row.blood_group] = row.units;
      b.stockVerified[row.blood_group] = row.verified ?? false;
      if (row.reported_at) {
        b.reported = true;
        b.lastUpdated = Math.max(b.lastUpdated, new Date(row.reported_at).getTime());
      }
    }
    setBanks(bankList);
    setStockLoading(false);
  }, []);

  useEffect(() => { loadBanks(); }, [loadBanks]);

  // Realtime subscription for stock changes
  useEffect(() => {
    const channel = supabase
      .channel('blood-stock-finder')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'blood_stock' }, (payload) => {
        const row = payload.new as BloodStock;
        if (!row) return;
        setBanks(prev => prev.map(b => {
          if (b.id !== row.bank_id) return b;
          return {
            ...b,
            stock: { ...b.stock, [row.blood_group]: row.units },
            stockVerified: { ...b.stockVerified, [row.blood_group]: row.verified ?? false },
            reported: true,
            lastUpdated: row.reported_at ? Math.max(b.lastUpdated, new Date(row.reported_at).getTime()) : b.lastUpdated,
          };
        }));
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  const triggerSync = useCallback(async () => {
    setSyncing(true);
    setSyncMessage('');
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/blood-bank-sync`;
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (user) {
        const { data: sessionData } = await supabase.auth.getSession();
        if (sessionData.session?.access_token) {
          headers['Authorization'] = `Bearer ${sessionData.session.access_token}`;
        } else {
          headers['Authorization'] = `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`;
        }
      } else {
        headers['Authorization'] = `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`;
      }
      const resp = await fetch(apiUrl, { method: 'POST', headers });
      const result = await resp.json() as { updated?: number; source?: string; error?: string };
      if (!resp.ok) throw new Error(result.error || 'sync_failed');
      setLastSync(new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }));
      setSyncMessage(result.updated
        ? `${result.updated} ${t('bb_stock_values_updated')}`
        : t('bb_no_verified_online_stock'));
      await loadBanks();
    } catch {
      setSyncMessage(t('bb_sync_failed'));
    } finally {
      setSyncing(false);
    }
  }, [loadBanks, t, user]);

  const reportedBanks = banks.filter(b => b.reported);

  const filteredPortals = GOVT_BLOOD_PORTALS.filter(p => {
    const q = searchQuery.toLowerCase().trim();
    return !q || p.name.toLowerCase().includes(q) || p.desc.toLowerCase().includes(q);
  });

  return (
    <div className="space-y-4">
      {/* Live stock header */}
      <div className="bg-white rounded-2xl border border-gray-200 p-4 animate-rise">
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <Droplet className="w-5 h-5 text-rose-500" />
          <h3 className="text-sm font-bold text-gray-900">{t('bb_live_stock_title')}</h3>
          <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${
            reportedBanks.length > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-sky-100 text-sky-700'
          }`}>
            {reportedBanks.length > 0 && <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />}
            {reportedBanks.length > 0 ? `${reportedBanks.length} ${t('bb_banks_live')}` : t('bb_syncing_wait')}
          </span>
          <button
            type="button"
            onClick={triggerSync}
            className="ml-auto flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full bg-rose-100 text-rose-700 hover:bg-rose-200 transition-all"
          >
            <RefreshCw className={`w-3 h-3 ${syncing ? 'animate-spin' : ''}`} />
            {lastSync ? `${t('updated')} ${lastSync}` : t('bb_sync_now')}
          </button>
        </div>
        <p className="text-sm text-gray-500 mb-2">{t('bb_live_stock_sub')}</p>
        {syncMessage && <p className="text-xs text-gray-500 mt-1 mb-2">{syncMessage}</p>}
      </div>

      {/* Live stock cards */}
      {stockLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => (
            <div key={i} className="bg-white rounded-2xl border border-gray-200 p-5 animate-pulse">
              <div className="h-5 bg-gray-100 rounded w-1/3 mb-3" />
              <div className="grid grid-cols-8 gap-2">
                {BLOOD_GROUPS.map(g => <div key={g} className="h-14 bg-gray-50 rounded-lg" />)}
              </div>
            </div>
          ))}
        </div>
      ) : reportedBanks.length > 0 ? (
        <div className="space-y-3">
          {reportedBanks.map((b, idx) => (
            <LiveStockCard key={b.id} bank={b} delay={idx * 50} />
          ))}
        </div>
      ) : (
        <div className="bg-sky-50 border border-sky-200 rounded-2xl p-5 flex items-center gap-3">
          <Activity className="w-5 h-5 text-sky-500 flex-none" />
          <p className="text-sm text-sky-700 font-medium">{t('bb_no_live_stock_yet')}</p>
        </div>
      )}

      {/* Portal links section */}
      <div className="bg-white rounded-2xl border border-gray-200 p-4 animate-rise">
        <div className="flex items-center gap-2 mb-3">
          <Shield className="w-5 h-5 text-rose-500" />
          <h3 className="text-sm font-bold text-gray-900">{t('bb_portals_title')}</h3>
        </div>
        <p className="text-sm text-gray-500 mb-4">{t('bb_portals_sub')}</p>

        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder={t('bb_portals_search_ph')}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-rose-400 focus:border-transparent transition-all"
          />
        </div>
      </div>

      {/* Portal cards */}
      {filteredPortals.length === 0 ? (
        <div className="text-center py-12 border-2 border-dashed border-gray-200 rounded-2xl text-gray-400">
          <Droplet className="w-8 h-8 mx-auto mb-2 opacity-30" />
          <p className="text-sm font-medium">{t('bb_no_portals')}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredPortals.map((p, idx) => (
            <a
              key={p.url}
              href={p.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block bg-white rounded-2xl border border-gray-200 p-5 hover:shadow-lg hover:shadow-rose-50 hover:border-rose-200 transition-all animate-rise group"
              style={{ animationDelay: `${idx * 60}ms` }}
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-50 grid place-items-center flex-none group-hover:bg-rose-100 group-hover:scale-110 transition-all">
                  <Shield className="w-5 h-5 text-rose-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h4 className="font-bold text-gray-900 text-sm group-hover:text-rose-700 transition-colors">{p.name}</h4>
                    <span className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">
                      <CheckCircle2 className="w-3 h-3" /> {t('bb_govt_certified')}
                    </span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1.5 leading-relaxed">{p.desc}</p>
                  <div className="flex items-center gap-1 mt-3 text-xs font-semibold text-rose-600 group-hover:text-rose-700">
                    <ExternalLink className="w-3.5 h-3.5" />
                    {t('bb_visit_portal')}
                  </div>
                </div>
              </div>
            </a>
          ))}
        </div>
      )}

      {/* Disclaimer */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-3.5 flex items-start gap-2.5">
        <AlertCircle className="w-4 h-4 text-amber-500 flex-none mt-0.5" />
        <p className="text-xs text-amber-700 font-medium leading-relaxed">{t('bb_disclaimer')}</p>
      </div>
    </div>
  );
}

function LiveStockCard({ bank, delay }: { bank: BankWithStock; delay: number }) {
  const { t } = useLang();
  const lastDate = bank.lastUpdated > 0 ? new Date(bank.lastUpdated).toLocaleString('en-GB', {
    day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit',
  }) : null;
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(bank.name + ' ' + (bank.address ?? bank.city))}`;

  return (
    <div
      className="bg-white rounded-2xl border border-gray-200 p-5 hover:shadow-lg hover:shadow-rose-50 transition-all animate-rise"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h4 className="font-bold text-gray-900 text-sm">{bank.name}</h4>
            {bank.verified && (
              <span className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">
                <CheckCircle2 className="w-3 h-3" /> {t('bb_verified')}
              </span>
            )}
          </div>
          {bank.address && (
            <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
              <MapPin className="w-3 h-3 flex-none" /> {bank.address}
            </p>
          )}
          <p className="text-xs text-gray-400 mt-0.5">
            {[bank.city, bank.district, bank.state].filter(Boolean).join(', ')}
            {bank.pincode && ` - ${bank.pincode}`}
          </p>
        </div>
        {lastDate && (
          <span className="text-xs text-gray-400 whitespace-nowrap flex items-center gap-1 flex-none">
            <Activity className="w-3 h-3" />
            {t('bb_last_updated')}: {lastDate}
          </span>
        )}
      </div>

      <div className="grid grid-cols-4 sm:grid-cols-8 gap-1.5 mb-3">
        {BLOOD_GROUPS.map(g => {
          const units = bank.stock[g] ?? 0;
          const isVerified = bank.stockVerified[g] ?? false;
          const isLow = bank.reported && units === 0;
          return (
            <div
              key={g}
              className={`rounded-lg py-2 text-center border transition-all ${
                isLow ? 'bg-rose-50/50 border-gray-200'
                  : units > 0 ? 'bg-emerald-50/50 border-emerald-100'
                  : 'bg-gray-50/50 border-gray-200'
              }`}
            >
              <span className="block text-xs font-bold text-gray-500">{g}</span>
              <span className={`block text-lg font-bold ${
                isLow ? 'text-rose-500' : units > 0 ? 'text-emerald-600' : 'text-gray-300'
              }`}>
                {bank.reported ? units : '—'}
              </span>
              {isVerified && <CheckCircle2 className="w-2.5 h-2.5 text-emerald-500 mx-auto mt-0.5" />}
            </div>
          );
        })}
      </div>

      <div className="flex items-center gap-2 flex-wrap">
        {bank.phone && (
          <a href={`tel:${bank.phone.replace(/[\s-]/g, '')}`} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-600 text-white font-semibold text-xs hover:bg-rose-700 active:scale-[.98] transition-all">
            <Phone className="w-3.5 h-3.5" />
            {t('bb_call_now')}
          </a>
        )}
        <a href={mapsUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-rose-200 text-rose-700 font-semibold text-xs hover:bg-rose-50 active:scale-[.98] transition-all">
          <Navigation className="w-3.5 h-3.5" />
          {t('get_directions')}
        </a>
      </div>
    </div>
  );
}


// ═══════════════════════════════════════════════════
// REQUEST TAB — Emergency blood request form + list
// ═══════════════════════════════════════════════════
function RequestTab() {
  const { t } = useLang();
  const { user } = useAuth();
  const toast = useToast();
  const [requests, setRequests] = useState<BloodRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  // Form fields
  const [patientName, setPatientName] = useState('');
  const [bloodGroup, setBloodGroup] = useState<BloodGroup>('O+');
  const [hospitalName, setHospitalName] = useState('');
  const [hospitalLocation, setHospitalLocation] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [unitsNeeded, setUnitsNeeded] = useState(1);
  const [urgency, setUrgency] = useState<'critical' | 'urgent' | 'moderate'>('critical');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const loadRequests = useCallback(async () => {
    const { data, error } = await supabase
      .from('blood_requests')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);
    if (error) { setLoading(false); return; }
    setRequests(data as BloodRequest[]);
    setLoading(false);
  }, []);

  useEffect(() => { loadRequests(); }, [loadRequests]);

  // Realtime
  useEffect(() => {
    const channel = supabase
      .channel('blood-requests-rt')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'blood_requests' }, (payload) => {
        setRequests(prev => [payload.new as BloodRequest, ...prev]);
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  function validate(): boolean {
    const e: Record<string, string> = {};
    if (!patientName.trim()) e.patientName = t('bb_err_required');
    if (!hospitalName.trim()) e.hospitalName = t('bb_err_required');
    if (!hospitalLocation.trim()) e.hospitalLocation = t('bb_err_required');
    if (!contactName.trim()) e.contactName = t('bb_err_required');
    if (!contactPhone.trim() || contactPhone.replace(/\D/g, '').length < 10) e.contactPhone = t('bb_err_phone');
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    const { error } = await supabase.from('blood_requests').insert({
      patient_name: patientName,
      blood_group: bloodGroup,
      hospital_name: hospitalName,
      hospital_location: hospitalLocation,
      contact_name: contactName,
      contact_phone: contactPhone,
      units_needed: unitsNeeded,
      urgency,
      notes: notes || null,
      user_id: user?.id ?? null,
    });
    setSubmitting(false);
    if (error) { toast(error.message, 'err'); return; }
    toast(t('bb_request_posted'));
    setPatientName(''); setHospitalName(''); setHospitalLocation('');
    setContactName(''); setContactPhone(''); setNotes('');
    setUnitsNeeded(1); setUrgency('critical');
  }

  const urgencyConfig = {
    critical: { label: t('bb_urgency_critical'), color: 'bg-rose-100 text-rose-700 border-rose-200', icon: Siren },
    urgent: { label: t('bb_urgency_urgent'), color: 'bg-amber-100 text-amber-700 border-amber-200', icon: AlertCircle },
    moderate: { label: t('bb_urgency_moderate'), color: 'bg-sky-100 text-sky-700 border-sky-200', icon: Clock },
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
      {/* Form */}
      <div className="bg-white rounded-2xl border border-gray-200 p-6 animate-rise">
        <div className="flex items-center gap-2.5 mb-1">
          <Siren className="w-5 h-5 text-rose-500" />
          <h2 className="text-lg font-bold text-gray-900">{t('bb_request_title')}</h2>
        </div>
        <p className="text-sm text-gray-500 mb-5">{t('bb_request_sub')}</p>

        {/* Emergency guidance */}
        <div className="bg-rose-50 border border-rose-200 rounded-xl p-3.5 mb-5 flex items-start gap-2.5">
          <Siren className="w-4 h-4 text-rose-500 flex-none mt-0.5" />
          <p className="text-xs text-rose-700 font-medium leading-relaxed">{t('bb_emergency_guidance')}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('bb_patient_name')}</label>
            <input
              type="text" value={patientName} onChange={e => setPatientName(e.target.value)}
              className={`w-full px-4 py-2.5 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-rose-400 transition-all ${
                errors.patientName ? 'border-rose-400' : 'border-gray-300'
              }`}
              placeholder={t('bb_patient_name_ph')}
            />
            {errors.patientName && <p className="text-xs text-rose-500 mt-1">{errors.patientName}</p>}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('blood_group')}</label>
              <div className="relative">
                <select
                  value={bloodGroup} onChange={e => setBloodGroup(e.target.value as BloodGroup)}
                  className="w-full appearance-none px-4 py-2.5 rounded-xl border border-gray-300 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-rose-400 bg-white pr-10"
                >
                  {BLOOD_GROUPS.map(g => <option key={g} value={g}>{g}</option>)}
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('bb_units_needed')}</label>
              <input
                type="number" value={unitsNeeded} min={1} max={20}
                onChange={e => setUnitsNeeded(Math.max(1, Math.min(20, parseInt(e.target.value, 10) || 1)))}
                className="w-full px-4 py-2.5 rounded-xl border border-gray-300 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-rose-400"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('bb_hospital_name')}</label>
            <input
              type="text" value={hospitalName} onChange={e => setHospitalName(e.target.value)}
              className={`w-full px-4 py-2.5 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-rose-400 transition-all ${
                errors.hospitalName ? 'border-rose-400' : 'border-gray-300'
              }`}
              placeholder={t('bb_hospital_name_ph')}
            />
            {errors.hospitalName && <p className="text-xs text-rose-500 mt-1">{errors.hospitalName}</p>}
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('bb_hospital_location')}</label>
            <input
              type="text" value={hospitalLocation} onChange={e => setHospitalLocation(e.target.value)}
              className={`w-full px-4 py-2.5 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-rose-400 transition-all ${
                errors.hospitalLocation ? 'border-rose-400' : 'border-gray-300'
              }`}
              placeholder={t('bb_hospital_location_ph')}
            />
            {errors.hospitalLocation && <p className="text-xs text-rose-500 mt-1">{errors.hospitalLocation}</p>}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('bb_contact_name')}</label>
              <input
                type="text" value={contactName} onChange={e => setContactName(e.target.value)}
                className={`w-full px-4 py-2.5 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-rose-400 transition-all ${
                  errors.contactName ? 'border-rose-400' : 'border-gray-300'
                }`}
                placeholder={t('bb_contact_name_ph')}
              />
              {errors.contactName && <p className="text-xs text-rose-500 mt-1">{errors.contactName}</p>}
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('bb_contact_phone')}</label>
              <input
                type="tel" value={contactPhone} onChange={e => setContactPhone(e.target.value)}
                className={`w-full px-4 py-2.5 rounded-xl border text-sm focus:outline-none focus:ring-2 focus:ring-rose-400 transition-all ${
                  errors.contactPhone ? 'border-rose-400' : 'border-gray-300'
                }`}
                placeholder="+91 98765 43210"
              />
              {errors.contactPhone && <p className="text-xs text-rose-500 mt-1">{errors.contactPhone}</p>}
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('bb_urgency_level')}</label>
            <div className="grid grid-cols-3 gap-2">
              {(['critical', 'urgent', 'moderate'] as const).map(u => {
                const cfg = urgencyConfig[u];
                const Icon = cfg.icon;
                return (
                  <button
                    key={u} type="button"
                    onClick={() => setUrgency(u)}
                    className={`flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-semibold border transition-all ${
                      urgency === u ? cfg.color + ' ring-2 ring-offset-1 ring-current' : 'bg-white border-gray-200 text-gray-400 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {cfg.label}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1.5">{t('bb_notes')} ({t('optional')})</label>
            <textarea
              value={notes} onChange={e => setNotes(e.target.value)} rows={2}
              className="w-full px-4 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-rose-400 resize-none"
              placeholder={t('bb_notes_ph')}
            />
          </div>

          <button
            type="submit" disabled={submitting}
            className="w-full py-3 rounded-xl bg-rose-600 text-white font-semibold text-sm hover:bg-rose-700 active:scale-[.98] transition-all disabled:opacity-60 shadow-lg shadow-rose-600/20"
          >
            {submitting ? t('bb_submitting') : t('bb_submit_request')}
          </button>
        </form>
      </div>

      {/* Active requests list */}
      <div className="bg-white rounded-2xl border border-gray-200 p-6 animate-rise [animation-delay:80ms]">
        <div className="flex items-center gap-2.5 mb-1">
          <Activity className="w-5 h-5 text-rose-500" />
          <h2 className="text-lg font-bold text-gray-900">{t('bb_active_requests')}</h2>
        </div>
        <p className="text-sm text-gray-500 mb-5">{t('bb_active_requests_sub')}</p>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => <div key={i} className="h-24 bg-gray-50 rounded-xl animate-pulse" />)}
          </div>
        ) : requests.length === 0 ? (
          <div className="text-center py-10 border-2 border-dashed border-gray-200 rounded-xl text-gray-400">
            <Siren className="w-7 h-7 mx-auto mb-2 opacity-30" />
            <p className="text-sm font-medium">{t('bb_no_requests')}</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
            {requests.map((r) => {
              const cfg = urgencyConfig[r.urgency as keyof typeof urgencyConfig] ?? urgencyConfig.critical;
              const Icon = cfg.icon;
              const timeAgoText = new Date(r.created_at).toLocaleString('en-GB', {
                day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit',
              });
              return (
                <div
                  key={r.id}
                  className={`rounded-xl border p-4 transition-all ${r.fulfilled ? 'opacity-50' : ''} ${cfg.color}`}
                >
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-bold">{r.blood_group}</span>
                      <span className="text-xs font-bold flex items-center gap-1">
                        <Icon className="w-3 h-3" /> {cfg.label}
                      </span>
                    </div>
                    <span className="text-xs opacity-70">{timeAgoText}</span>
                  </div>
                  <p className="text-sm font-semibold text-gray-900">{r.patient_name}</p>
                  <p className="text-xs text-gray-600 mt-0.5">{r.hospital_name}, {r.hospital_location}</p>
                  <p className="text-xs text-gray-500 mt-1">{t('bb_units_needed')}: {r.units_needed}</p>
                  {r.notes && <p className="text-xs text-gray-500 mt-1 italic">"{r.notes}"</p>}
                  <div className="flex items-center gap-2 mt-3">
                    <a
                      href={`tel:${telLink(r.contact_phone)}`}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 text-white font-semibold text-xs hover:bg-rose-700 transition-all"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      {r.contact_name}
                    </a>
                    <span className="text-xs text-gray-400">{r.contact_phone}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════
// ADMIN TAB — CRUD blood banks, import CSV, verify
// ═══════════════════════════════════════════════════
function AdminTab() {
  const { t } = useLang();
  const toast = useToast();
  const [banks, setBanks] = useState<BloodBank[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<BloodBank | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [csvText, setCsvText] = useState('');
  const [showCsv, setShowCsv] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const loadBanks = useCallback(async () => {
    const { data, error } = await supabase.from('blood_banks').select('*').order('name');
    if (error) { toast(error.message, 'err'); setLoading(false); return; }
    setBanks(data as BloodBank[]);
    setLoading(false);
  }, [toast]);

  useEffect(() => { loadBanks(); }, [loadBanks]);

  async function handleDelete(id: string) {
    const { error } = await supabase.from('blood_banks').delete().eq('id', id);
    if (error) { toast(error.message, 'err'); return; }
    toast(t('bb_deleted'));
    loadBanks();
  }

  async function handleVerify(id: string) {
    const { error } = await supabase
      .from('blood_banks')
      .update({ verified: true, last_verified_at: new Date().toISOString() })
      .eq('id', id);
    if (error) { toast(error.message, 'err'); return; }
    toast(t('bb_verified_success'));
    loadBanks();
  }

  async function handleCsvImport() {
    if (!csvText.trim()) { toast(t('bb_csv_empty'), 'err'); return; }
    const lines = csvText.trim().split('\n');
    const rows: Record<string, string>[] = [];
    const headers = lines[0].toLowerCase().split(',').map(h => h.trim());

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(',').map(v => v.trim());
      const row: Record<string, string> = {};
      headers.forEach((h, idx) => { row[h] = values[idx] ?? ''; });
      rows.push(row);
    }

    const inserts = rows.map(r => ({
      name: r.name || r['blood bank name'] || '',
      address: r.address || null,
      phone: r.phone || r.contact || null,
      city: r.city || 'Unknown',
      district: r.district || null,
      state: r.state || 'Andhra Pradesh',
      pincode: r.pincode || r.pin || null,
      operating_hours: r['operating hours'] || r.hours || null,
      data_source: 'csv_import',
    })).filter(r => r.name);

    if (inserts.length === 0) { toast(t('bb_csv_no_rows'), 'err'); return; }

    const { error } = await supabase.from('blood_banks').insert(inserts);
    if (error) { toast(error.message, 'err'); return; }
    toast(`${inserts.length} ${t('bb_csv_imported')}`);
    setCsvText(''); setShowCsv(false);
    loadBanks();
  }

  return (
    <div className="space-y-4">
      {/* Admin header */}
      <div className="bg-white rounded-2xl border border-gray-200 p-4 animate-rise">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2.5">
            <Shield className="w-5 h-5 text-rose-500" />
            <h3 className="text-sm font-bold text-gray-900">{t('bb_admin_title')}</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setShowCsv(!showCsv)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-gray-300 text-gray-700 font-semibold text-xs hover:bg-gray-50 transition-all"
            >
              <Upload className="w-3.5 h-3.5" />
              {t('bb_import_csv')}
            </button>
            <button
              type="button"
              onClick={() => { setEditing(null); setShowForm(true); }}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-600 text-white font-semibold text-xs hover:bg-rose-700 transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              {t('bb_add_bank')}
            </button>
          </div>
        </div>
      </div>

      {/* CSV import */}
      {showCsv && (
        <div className="bg-white rounded-2xl border border-gray-200 p-5 animate-rise">
          <h4 className="text-sm font-bold text-gray-900 mb-2">{t('bb_csv_format')}</h4>
          <p className="text-xs text-gray-400 mb-3">
            {t('bb_csv_format_help')}
          </p>
          <textarea
            value={csvText} onChange={e => setCsvText(e.target.value)} rows={6}
            className="w-full px-4 py-3 rounded-xl border border-gray-300 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-rose-400 resize-none mb-3"
            placeholder="name,address,phone,city,district,state,pincode,operating hours&#10;Govt Blood Bank,Main Road,9876543210,Ongole,Prakasam,Andhra Pradesh,523001,24x7"
          />
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCsvImport}
              className="px-4 py-2 rounded-xl bg-rose-600 text-white font-semibold text-xs hover:bg-rose-700 transition-all"
            >
              {t('bb_import')}
            </button>
            <button
              type="button"
              onClick={() => { setShowCsv(false); setCsvText(''); }}
              className="px-4 py-2 rounded-xl border border-gray-300 text-gray-600 font-semibold text-xs hover:bg-gray-50 transition-all"
            >
              {t('clear')}
            </button>
          </div>
        </div>
      )}

      {/* Edit/Add form */}
      {showForm && (
        <BankForm
          bank={editing}
          onSave={() => { setShowForm(false); setEditing(null); loadBanks(); }}
          onCancel={() => { setShowForm(false); setEditing(null); }}
        />
      )}

      {/* Bank list */}
      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3, 4, 5].map(i => <div key={i} className="h-16 bg-gray-50 rounded-xl animate-pulse" />)}
        </div>
      ) : (
        <div className="space-y-2">
          {banks.map(b => (
            <div
              key={b.id}
              className="bg-white rounded-xl border border-gray-200 p-4 flex items-center justify-between gap-3 hover:shadow-md transition-all"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="font-semibold text-gray-900 text-sm">{b.name}</p>
                  {b.verified ? (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">
                      <CheckCircle2 className="w-3 h-3" /> {t('bb_verified')}
                    </span>
                  ) : (
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-amber-100 text-amber-700">
                      {t('bb_unverified')}
                    </span>
                  )}
                </div>
                <p className="text-xs text-gray-400 mt-0.5">
                  {b.city}, {b.district ?? '—'}, {b.state} {b.pincode ?? ''}
                </p>
                {b.last_verified_at && (
                  <p className="text-xs text-gray-300 mt-0.5">
                    {t('bb_last_verified')}: {new Date(b.last_verified_at).toLocaleDateString('en-GB')}
                  </p>
                )}
              </div>
              <div className="flex items-center gap-1.5 flex-none">
                {!b.verified && (
                  <button
                    type="button" onClick={() => handleVerify(b.id)}
                    className="p-2 rounded-lg text-emerald-600 hover:bg-emerald-50 transition-all"
                    title={t('bb_verify')}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                  </button>
                )}
                <button
                  type="button" onClick={() => { setEditing(b); setShowForm(true); }}
                  className="p-2 rounded-lg text-sky-600 hover:bg-sky-50 transition-all"
                  title={t('bb_edit')}
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  type="button" onClick={() => setDeleteId(b.id)}
                  className="p-2 rounded-lg text-rose-500 hover:bg-rose-50 transition-all"
                  title={t('bb_delete')}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <ConfirmDialog
        open={deleteId !== null}
        title={t('bb_delete')}
        message={t('bb_confirm_delete')}
        confirmLabel={t('bb_delete')}
        cancelLabel={t('clear')}
        onConfirm={() => {
          if (deleteId) handleDelete(deleteId);
          setDeleteId(null);
        }}
        onCancel={() => setDeleteId(null)}
      />
    </div>
  );
}

function BankForm({ bank, onSave, onCancel }: {
  bank: BloodBank | null; onSave: () => void; onCancel: () => void;
}) {
  const { t } = useLang();
  const toast = useToast();
  const [saving, setSaving] = useState(false);
  const [name, setName] = useState(bank?.name ?? '');
  const [address, setAddress] = useState(bank?.address ?? '');
  const [phone, setPhone] = useState(bank?.phone ?? '');
  const [city, setCity] = useState(bank?.city ?? '');
  const [district, setDistrict] = useState(bank?.district ?? '');
  const [state, setState] = useState(bank?.state ?? 'Andhra Pradesh');
  const [pincode, setPincode] = useState(bank?.pincode ?? '');
  const [operatingHours, setOperatingHours] = useState(bank?.operating_hours ?? '');

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !city.trim()) { toast(t('bb_err_required'), 'err'); return; }
    setSaving(true);
    const payload = {
      name: name.trim(),
      address: address.trim() || null,
      phone: phone.trim() || null,
      city: city.trim(),
      district: district.trim() || null,
      state: state.trim(),
      pincode: pincode.trim() || null,
      operating_hours: operatingHours.trim() || null,
    };

    const { error } = bank
      ? await supabase.from('blood_banks').update(payload).eq('id', bank.id)
      : await supabase.from('blood_banks').insert({ ...payload, data_source: 'manual' });

    setSaving(false);
    if (error) { toast(error.message, 'err'); return; }
    toast(bank ? t('bb_updated') : t('bb_added'));
    onSave();
  }

  return (
    <div className="bg-white rounded-2xl border border-gray-200 p-5 animate-rise">
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-sm font-bold text-gray-900">{bank ? t('bb_edit_bank') : t('bb_add_bank')}</h4>
        <button type="button" onClick={onCancel} className="p-1.5 rounded-lg text-gray-400 hover:bg-gray-100">
          <X className="w-4 h-4" />
        </button>
      </div>

      <form onSubmit={handleSave} className="space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <FormField label={t('bb_bank_name')} value={name} onChange={setName} required />
          <FormField label={t('bb_phone')} value={phone} onChange={setPhone} />
          <FormField label={t('bb_city')} value={city} onChange={setCity} required />
          <FormField label={t('bb_district')} value={district} onChange={setDistrict} />
          <FormField label={t('bb_state')} value={state} onChange={setState} />
          <FormField label={t('bb_pincode')} value={pincode} onChange={setPincode} />
          <FormField label={t('bb_operating_hours')} value={operatingHours} onChange={setOperatingHours} />
        </div>
        <FormField label={t('bb_address')} value={address} onChange={setAddress} fullWidth />

        <div className="flex items-center gap-2 pt-2">
          <button
            type="submit" disabled={saving}
            className="px-5 py-2.5 rounded-xl bg-rose-600 text-white font-semibold text-sm hover:bg-rose-700 disabled:opacity-60 transition-all"
          >
            {saving ? t('saving') : (bank ? t('bb_save') : t('bb_add_bank'))}
          </button>
          <button
            type="button" onClick={onCancel}
            className="px-5 py-2.5 rounded-xl border border-gray-300 text-gray-600 font-semibold text-sm hover:bg-gray-50 transition-all"
          >
            {t('clear')}
          </button>
        </div>
      </form>
    </div>
  );
}

function FormField({ label, value, onChange, required, fullWidth }: {
  label: string; value: string; onChange: (v: string) => void; required?: boolean; fullWidth?: boolean;
}) {
  return (
    <div className={fullWidth ? '' : ''}>
      <label className="block text-sm font-semibold text-gray-600 mb-1.5">
        {label}{required && <span className="text-rose-500"> *</span>}
      </label>
      <input
        type="text" value={value} onChange={e => onChange(e.target.value)} required={required}
        className="w-full px-4 py-2.5 rounded-xl border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-rose-400 focus:border-transparent transition-all"
      />
    </div>
  );
}
