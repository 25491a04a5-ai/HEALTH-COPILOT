export interface HospitalDepartment {
  name: string;
  specialist: string;
  phone: string | null;
}

export interface Hospital {
  id: string;
  name: string;
  specialty: string;
  address: string | null;
  phone: string | null;
  has_emergency: boolean;
  zone: string;
  state: string;
  district: string | null;
  departments: HospitalDepartment[] | null;
  hospital_type: string | null;
  beds: number | null;
  services: string[] | null;
}

export interface BloodBank {
  id: string;
  name: string;
  address: string | null;
  phone: string | null;
  city: string;
  district: string | null;
  state: string | null;
  pincode: string | null;
  latitude: number | null;
  longitude: number | null;
  operating_hours: string | null;
  data_source: string | null;
  verified: boolean | null;
  last_verified_at: string | null;
}

export interface BloodStock {
  id: string;
  bank_id: string;
  blood_group: string;
  units: number;
  reported_at: string | null;
  verified: boolean | null;
  source: string | null;
}

export interface PatientReport {
  id: string;
  user_id: string;
  title: string;
  type: string;
  report_date: string;
  hospital: string | null;
  file_url: string | null;
  created_at: string;
}

export interface BankStaff {
  id: string;
  user_id: string;
  bank_id: string;
}

export type BloodGroup = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';

export const BLOOD_GROUPS: BloodGroup[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export type ReportType = 'Lab' | 'Prescription' | 'Scan' | 'Discharge';

export const REPORT_TYPES: ReportType[] = ['Lab', 'Prescription', 'Scan', 'Discharge'];

export interface BankWithStock extends BloodBank {
  stock: Record<string, number>;
  stockVerified: Record<string, boolean>;
  reported: boolean;
  lastUpdated: number;
}

export interface BloodRequest {
  id: string;
  patient_name: string;
  blood_group: string;
  hospital_name: string;
  hospital_location: string;
  contact_name: string;
  contact_phone: string;
  units_needed: number;
  urgency: string;
  notes: string | null;
  fulfilled: boolean;
  user_id: string | null;
  created_at: string;
}

export interface BloodBankAdmin {
  id: string;
  user_id: string;
  created_at: string;
}
