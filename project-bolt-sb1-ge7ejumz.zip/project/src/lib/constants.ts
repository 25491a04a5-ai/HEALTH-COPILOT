import { BloodGroup, BLOOD_GROUPS } from './types';

export const SPECIALTIES = [
  'Cardiology',
  'Pulmonology',
  'Neurology',
  'Gastroenterology',
  'Urology',
  'Dermatology',
  'Orthopaedics',
  'Ophthalmology',
  'ENT',
  'General medicine',
] as const;

export type SpecialtyKey =
  | 'cardio' | 'pulmo' | 'neuro' | 'gastro' | 'uro'
  | 'derm' | 'ortho' | 'ophth' | 'ent' | 'gen';

export const SPECIALTY_MAP: Record<SpecialtyKey, string> = {
  cardio: 'Cardiology',
  pulmo: 'Pulmonology',
  neuro: 'Neurology',
  gastro: 'Gastroenterology',
  uro: 'Urology',
  derm: 'Dermatology',
  ortho: 'Orthopaedics',
  ophth: 'Ophthalmology',
  ent: 'ENT',
  gen: 'General medicine',
};

export const SPECIALTY_LABEL_KEY: Record<string, string> = {
  'Cardiology': 'spec_cardio',
  'Pulmonology': 'spec_pulmo',
  'Neurology': 'spec_neuro',
  'Gastroenterology': 'spec_gastro',
  'Urology': 'spec_uro',
  'Dermatology': 'spec_derm',
  'Orthopaedics': 'spec_ortho',
  'Ophthalmology': 'spec_ophth',
  'ENT': 'spec_ent',
  'General medicine': 'spec_gen',
  'Gynaecology': 'spec_gen',
};

export const HOSPITAL_TYPE_LABEL_KEY: Record<string, string> = {
  'Government': 'govt_hospital',
  'Private': 'private_hospital',
  'Super Speciality': 'super_speciality',
  'Cancer': 'cancer_hospital',
};

export const REPORT_TYPE_LABEL_KEY: Record<string, string> = {
  'Lab': 'type_lab',
  'Prescription': 'type_prescription',
  'Scan': 'type_scan',
  'Discharge': 'type_discharge',
};

export function translateSpecialty(specialty: string, t: (k: string) => string): string {
  const key = SPECIALTY_LABEL_KEY[specialty];
  return key ? t(key) : specialty;
}

export function translateHospitalType(type: string, t: (k: string) => string): string {
  const key = HOSPITAL_TYPE_LABEL_KEY[type];
  return key ? t(key) : type;
}

export type BodyArea = 'head' | 'chest' | 'abdomen' | 'limbs' | 'skin';

export interface Symptom {
  id: string;
  labelKey: string;
  label: string;
  bodyArea: BodyArea;
  weights: Partial<Record<SpecialtyKey, number>>;
}

export const SYMPTOMS: Symptom[] = [
  { id: 'chest', labelKey: 'sym_chest', label: 'Chest pain or pressure', bodyArea: 'chest', weights: { cardio: 3, pulmo: 1 } },
  { id: 'breath', labelKey: 'sym_breath', label: 'Severe shortness of breath', bodyArea: 'chest', weights: { pulmo: 3, cardio: 2 } },
  { id: 'cough', labelKey: 'sym_cough', label: 'Persistent cough or wheezing', bodyArea: 'chest', weights: { pulmo: 3 } },
  { id: 'numb', labelKey: 'sym_numb', label: 'Face drooping, arm weakness or slurred speech', bodyArea: 'head', weights: { neuro: 3 } },
  { id: 'headache', labelKey: 'sym_headache', label: 'Headache', bodyArea: 'head', weights: { neuro: 2, gen: 1 } },
  { id: 'dizzy', labelKey: 'sym_dizzy', label: 'Dizziness', bodyArea: 'head', weights: { neuro: 2, cardio: 1, gen: 1 } },
  { id: 'eye', labelKey: 'sym_eye', label: 'Eye pain or blurred vision', bodyArea: 'head', weights: { ophth: 3 } },
  { id: 'ear', labelKey: 'sym_ear', label: 'Ear or throat pain', bodyArea: 'head', weights: { ent: 3 } },
  { id: 'bleed', labelKey: 'sym_bleed', label: 'Bleeding that will not stop', bodyArea: 'skin', weights: {} },
  { id: 'rash', labelKey: 'sym_rash', label: 'Skin rash or itching', bodyArea: 'skin', weights: { derm: 3 } },
  { id: 'belly', labelKey: 'sym_belly', label: 'Belly pain or vomiting', bodyArea: 'abdomen', weights: { gastro: 3 } },
  { id: 'burn', labelKey: 'sym_burn', label: 'Burning when passing urine', bodyArea: 'abdomen', weights: { uro: 3 } },
  { id: 'nausea', labelKey: 'sym_nausea', label: 'Nausea or loss of appetite', bodyArea: 'abdomen', weights: { gastro: 2, gen: 1 } },
  { id: 'joint', labelKey: 'sym_joint', label: 'Joint or back pain', bodyArea: 'limbs', weights: { ortho: 3 } },
  { id: 'swelling', labelKey: 'sym_swelling', label: 'Swelling in legs or ankles', bodyArea: 'limbs', weights: { ortho: 2, cardio: 1 } },
  { id: 'weakness', labelKey: 'sym_weakness', label: 'General weakness or fatigue', bodyArea: 'limbs', weights: { gen: 2, cardio: 1 } },
];

export const EMERGENCY_SYMPTOMS = ['chest', 'breath', 'numb', 'bleed'];

export const BODY_AREAS: { key: BodyArea; icon: string; labelKey: string }[] = [
  { key: 'head', icon: 'head', labelKey: 'body_head' },
  { key: 'chest', icon: 'chest', labelKey: 'body_chest' },
  { key: 'abdomen', icon: 'abdomen', labelKey: 'body_abdomen' },
  { key: 'limbs', icon: 'limbs', labelKey: 'body_limbs' },
  { key: 'skin', icon: 'skin', labelKey: 'body_skin' },
];

export const CITIES = ['Ongole', 'Guntur', 'Narsaraopeta'] as const;

// State → District → City hierarchy for dropdowns
export interface StateInfo {
  name: string;
  districts: { name: string; cities: string[] }[];
}

export const INDIA_STATES: StateInfo[] = [
  {
    name: 'Andhra Pradesh',
    districts: [
      { name: 'Prakasam', cities: ['Ongole', 'Chirala', 'Markapur'] },
      { name: 'Guntur', cities: ['Guntur', 'Narsaraopeta', 'Tenali'] },
      { name: 'Krishna', cities: ['Vijayawada', 'Machilipatnam'] },
      { name: 'Chittoor', cities: ['Tirupati', 'Chittoor'] },
      { name: 'Visakhapatnam', cities: ['Visakhapatnam', 'Anakapalle'] },
    ],
  },
  {
    name: 'Telangana',
    districts: [
      { name: 'Hyderabad', cities: ['Hyderabad'] },
      { name: 'Rangareddy', cities: ['Hyderabad', 'LB Nagar'] },
      { name: 'Warangal', cities: ['Warangal'] },
    ],
  },
  {
    name: 'Karnataka',
    districts: [
      { name: 'Bengaluru Urban', cities: ['Bengaluru'] },
      { name: 'Mysuru', cities: ['Mysuru'] },
    ],
  },
  {
    name: 'Tamil Nadu',
    districts: [
      { name: 'Chennai', cities: ['Chennai'] },
      { name: 'Coimbatore', cities: ['Coimbatore'] },
    ],
  },
];

// Government-certified blood bank portals for real-time stock info
export interface GovtPortal {
  name: string;
  url: string;
  desc: string;
}

export const GOVT_BLOOD_PORTALS: GovtPortal[] = [
  {
    name: 'e-Raktkosh — Blood Stock Availability',
    url: 'https://eraktkosh.mohfw.gov.in/BLDAHIMS/bloodbank/stockAvailability.cnt',
    desc: 'Ministry of Health & Family Welfare, Government of India — real-time blood stock across all registered blood banks nationwide',
  },
  {
    name: 'e-Raktkosh — Nearby Blood Bank Search',
    url: 'https://eraktkosh.mohfw.gov.in/BLDAHIMS/bloodbank/nearbyBloodBank.cnt',
    desc: 'Official Government of India portal to find nearby blood banks by state, district and blood group',
  },
  {
    name: 'e-BloodBank (NIC)',
    url: 'https://ebloodbank.gov.in',
    desc: 'National Informatics Centre — government blood bank management system covering 200+ blood banks in Andhra Pradesh',
  },
  {
    name: 'Andhra Pradesh Red Cross Blood Centres',
    url: 'https://www.apredcross.org',
    desc: 'Indian Red Cross Society, Andhra Pradesh Branch — government recognised blood centres across AP districts',
  },
  {
    name: 'IRCS National Blood Centre Directory',
    url: 'https://www.indianredcross.org/ircs/ircsbloodbanks',
    desc: 'Indian Red Cross Society — official list of Red Cross blood centres across all states including Andhra Pradesh',
  },
  {
    name: 'Blood Banks — Prakasam District, AP',
    url: 'https://prakasam.ap.gov.in/public-utility-category/blood-banks',
    desc: 'Government of Andhra Pradesh — official district blood bank directory with addresses and contact numbers',
  },
  {
    name: 'Blood Transfusion Services — DGHS',
    url: 'https://dghs.mohfw.gov.in/bts.php',
    desc: 'Directorate General of Health Services, Ministry of Health — national blood transfusion policy and portal links',
  },
];

export { BLOOD_GROUPS };

export function telLink(phone: string): string {
  return phone.replace(/[\s-]/g, '');
}

export function formatDate(dateStr: string): string {
  return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
}

export function timeAgo(timestamp: number): { text: string; cls: string } {
  const minutes = Math.round((Date.now() - timestamp) / 60000);
  if (minutes < 60) return { text: `${minutes} min ago`, cls: 'p-ok' };
  if (minutes < 360) return { text: `${Math.round(minutes / 60)} h ago`, cls: 'p-ok' };
  if (minutes < 1440) return { text: `${Math.round(minutes / 60)} h ago`, cls: 'p-warn' };
  return { text: `${Math.round(minutes / 1440)} d ago`, cls: 'p-crit' };
}
