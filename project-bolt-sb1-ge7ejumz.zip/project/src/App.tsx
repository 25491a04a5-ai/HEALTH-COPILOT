import { useState, useEffect } from 'react';
import { Heart, FileText, Stethoscope, Building2, LogOut, Activity, Globe, Droplet } from 'lucide-react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { LangProvider, useLang } from '@/context/LangContext';
import { ToastProvider } from '@/components/Toast';
import AuthPage from '@/components/AuthPage';
import ReportsView from '@/components/ReportsView';
import SymptomsView from '@/components/SymptomsView';
import CareView from '@/components/CareView';
import BloodBankView from '@/components/BloodBankView';
import { supabase } from '@/lib/supabase';
import { Hospital } from '@/lib/types';
import { LANGS, Lang } from '@/lib/i18n';

type ViewKey = 'reports' | 'symptoms' | 'care' | 'bloodbank';

const NAV_KEYS: { key: ViewKey; labelKey: string; subKey: string; icon: typeof FileText }[] = [
  { key: 'reports', labelKey: 'nav_reports', subKey: 'sub_reports', icon: FileText },
  { key: 'symptoms', labelKey: 'nav_symptoms', subKey: 'sub_symptoms', icon: Stethoscope },
  { key: 'care', labelKey: 'nav_care', subKey: 'sub_care', icon: Building2 },
  { key: 'bloodbank', labelKey: 'nav_bloodbank', subKey: 'sub_bloodbank', icon: Droplet },
];

function LanguageSwitcher({ dark }: { dark: boolean }) {
  const { lang, setLang } = useLang();
  return (
    <div className={`flex items-center gap-1 rounded-xl p-1 ${dark ? 'bg-teal-900/50' : 'bg-gray-100'}`}>
      {LANGS.map(l => (
        <button
          key={l.code}
          type="button"
          onClick={() => setLang(l.code as Lang)}
          className={`px-2 py-1 rounded-lg text-xs font-semibold transition-all ${
            lang === l.code
              ? dark ? 'bg-teal-600 text-white' : 'bg-white text-gray-900 shadow-sm'
              : dark ? 'text-teal-300 hover:text-white' : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          {l.native}
        </button>
      ))}
    </div>
  );
}

function Dashboard() {
  const { user, signOut } = useAuth();
  const { t } = useLang();
  const [view, setView] = useState<ViewKey>('reports');
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [careSpecialty, setCareSpecialty] = useState('');

  useEffect(() => {
    supabase.from('hospitals').select('*').order('name').then(({ data }) => {
      if (data) setHospitals(data as Hospital[]);
    });
  }, []);

  const userName = user?.user_metadata?.full_name || user?.email || t('signed_in');
  const initial = userName.charAt(0).toUpperCase();
  const currentNav = NAV_KEYS.find(n => n.key === view)!;

  function handleFindHospitals(specialty: string) {
    setCareSpecialty(specialty);
    setView('care');
  }

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* Sidebar */}
      <aside className="w-60 bg-teal-950 text-teal-100 flex flex-col flex-none sticky top-0 h-screen">
        <div className="p-5 flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-teal-400 to-cyan-400 grid place-items-center shadow-lg shadow-teal-900/50">
            <Heart className="w-5 h-5 text-teal-950" fill="currentColor" />
          </div>
          <span className="text-lg font-bold tracking-tight text-white">{t('app_name')}</span>
        </div>

        <nav className="flex flex-col gap-1 px-3 mt-2">
          {NAV_KEYS.map(n => {
            const Icon = n.icon;
            return (
              <button
                key={n.key}
                type="button"
                onClick={() => setView(n.key)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold text-left transition-all ${
                  view === n.key
                    ? 'bg-teal-800 text-white shadow-[inset_3px_0_0_0_#14b8a6]'
                    : 'text-teal-300 hover:bg-teal-900 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4 flex-none" />
                {t(n.labelKey)}
              </button>
            );
          })}
        </nav>

        <div className="mt-auto p-4 space-y-3">
          <div className="flex items-center gap-2 text-sm text-teal-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-medium">{t('live')}</span>
          </div>

          <LanguageSwitcher dark />

          <div className="flex items-center gap-2.5 min-w-0">
            <span className="w-8 h-8 rounded-full bg-teal-400 text-teal-950 grid place-items-center font-bold text-sm flex-none">
              {initial}
            </span>
            <span className="text-sm text-teal-100 truncate">{userName}</span>
          </div>

          <button
            type="button"
            onClick={signOut}
            className="w-full py-2 rounded-xl border border-teal-800 text-teal-200 text-sm font-semibold hover:bg-teal-900 transition-all flex items-center justify-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            {t('sign_out')}
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 min-w-0">
        <header className="bg-white border-b border-gray-200 px-7 py-4 sticky top-0 z-10 flex items-center justify-between gap-3 flex-wrap">
          <div>
            <h1 className="text-xl font-bold text-gray-900">{t(currentNav.labelKey)}</h1>
            <p className="text-sm text-gray-500 mt-0.5">{t(currentNav.subKey)}</p>
          </div>
          <div className="flex items-center gap-1.5 text-xs font-semibold text-teal-700 bg-teal-50 px-3 py-1.5 rounded-full">
            <Activity className="w-3.5 h-3.5" />
            {t('real_time')}
          </div>
        </header>

        <div className="p-6 lg:p-7 max-w-[1200px]">
          {view === 'reports' && <ReportsView />}
          {view === 'symptoms' && (
            <SymptomsView hospitals={hospitals} onFindHospitals={handleFindHospitals} />
          )}
          {view === 'care' && <CareView initialSpecialty={careSpecialty} />}
          {view === 'bloodbank' && <BloodBankView />}
        </div>
      </main>
    </div>
  );
}

function Root() {
  const { user, loading } = useAuth();
  const { t } = useLang();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 grid place-items-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-teal-500 to-cyan-500 grid place-items-center animate-pulse">
            <Heart className="w-6 h-6 text-white" fill="currentColor" />
          </div>
          <p className="text-sm text-gray-400 font-medium">{t('loading')}</p>
        </div>
      </div>
    );
  }

  return user ? <Dashboard /> : <AuthPage />;
}

export default function App() {
  return (
    <LangProvider>
      <AuthProvider>
        <ToastProvider>
          <Root />
        </ToastProvider>
      </AuthProvider>
    </LangProvider>
  );
}
